<?php
session_start();
if ( !isset( $_SESSION[ 's_email' ] ) )
	header( 'Location:../' );
$path = "Uploads/";
include '../Php_Include/dbcon.php';
$username = $_SESSION[ 's_email' ];
$sql0 = "select * from students where rollno='$username'";
$result0 = mysqli_query( $con, $sql0 )or die( mysqli_error( $con ) );
$row0 = mysqli_fetch_array( $result0 );
$rollno = $row0[ 'Rollno' ];
$student_name = $row0[ 'Name' ];
$sql = "SELECT * FROM departments WHERE dept_id = '" . $row0[ 'Dept_Id' ] . "'";
$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
$row3 = mysqli_fetch_array( $result );
$dept_id = $row3[ 'Dept_Id' ];
$sql = "SELECT count(*) FROM departments";
$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
$row00 = mysqli_fetch_array( $result );
?>
<!DOCTYPE html>
<html>

<head>
	<title>
		<?php echo ucwords($student_name);?>'s | Feedback</title>
	<?php include ("../Php_Include/Header_Footer_Files/Header_Include.php") ;?>
</head>
<?php include ("../Php_Include/For_Students/StudentAction.php");?>

<body class="hold-transition skin-blue sidebar-mini" onLoad="document.forms.search.part.focus()">
	<div class="wrapper">
		<header class="main-header">
			<!-- Logo -->
			<a href="#" class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><img src="../img/logo_s.jpg" style="width:50px;height:50px;" /></span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg" style="height:auto;width:auto;"><img src="../img/logo_l.png" style="height:50px;width:100%;margin-left:0px;margin-top:-8px;margin-right:0px" /></span>
			</a>

			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
			
				<!-- Navbar Right Menu -->
				<div class="navbar-custom-menu">
					<ul class="nav navbar-nav">
						<!-- User Account: style can be found in dropdown.less -->
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
			 <img src="<?php echo $path.$row0['Photo'];?>" alt="Pic" class="user-image" />
              <span class="hidden-xs"><?php echo($student_name);?></span>
            </a>
						
							<ul class="dropdown-menu">
								<!-- User image -->
								<li class="user-header">
									<img src="<?php echo $path.$row0['Photo'];?>" alt="Pic" class="img-circle"/>
									<button type="button" name="add" id="add" class="btn btn-success"><i class="fa fa-pencil"></i></button>
									<p>
										<?php echo ucwords($student_name);?>
										<small>Student of <?php echo ucwords($row3['Dept_Name']);?></small>
									</p>
								</li>
								<!-- Menu Footer-->
								<li class="user-footer">
									<div class="pull-left">
										<a data-toggle="modal" data-target="#profile" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right">
										<a href="../Php_Include/Logout.php" class="btn btn-default btn-flat">Sign out</a>
									</div>
								</li>
							</ul>
						</li>
						<!-- Control Sidebar Toggle Button -->
						<li>
							<a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
						</li>
					</ul>
				</div>

			</nav>
		</header>
		<!-- Left side column. contains the logo and sidebar -->
		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				<!-- search form -->
				<form action="#" method="get" class="sidebar-form">
					<div class="input-group">
						<input type="text" name="q" class="form-control" placeholder="Search...">
						<span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
					
					</div>
				</form>
				<!-- /.search form -->
				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu" data-widget="tree">
					<li><a href="Students.php" class="fa fa-dashboard"></i><span> Dashboard</span></a>
					</li>
					<li class="active"><a href="Feedback.php"><i class="fa fa-circle"></i><span>Feedback</span></a>
					</li>
					<li><a href="StudentAttendence.php"><i class="fa fa-envelope"></i> <span>Attendence</span></a>
					</li>
					<li class="header">LABELS</li>
					<li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a>
					</li>
					<li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a>
					</li>
					<li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a>
					</li>
				</ul>
			</section>
			<!-- /.sidebar -->
		</aside>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
			
				<ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> Home</a>
					</li>
					<li class="active">Dashboard</li>
				</ol>
			</section>
			<!-- Main content -->
			<section class="content">
				<!-- Info boxes -->
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-aqua"><i class="ion ion-ios-home-outline"></i></span>

							<div class="info-box-content">
								<span class="info-box-text">No. Of Departments</span>
								<span class="info-box-number">
									<?php echo $row00['count(*)'];?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>
							<?php
							$sql11 = "select count(*) from students where Semester_id= '" . $row0[ 'Semester_Id' ] . "'";
							$result11 = mysqli_query( $con, $sql11 )or die( mysqli_error( $con ) );
							$row11 = mysqli_fetch_array( $result11 );
							?>
							<div class="info-box-content">
								<span class="info-box-text">Total Students Of College</span>
								<span class="info-box-number">
									<?php echo $row11['count(*)']; ?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<!-- fix for small devices only -->
					<div class="clearfix visible-sm-block"></div>

					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-green"><i class="ion ion-ios-book-outline"></i></span>

							<div class="info-box-content">
								<span class="info-box-text">Total Result Entries</span>
								<?php
								$sql12 = "select count(*) from exam_performance where Student_Rollno='$rollno'";
								$result12 = mysqli_query( $con, $sql12 )or die( mysqli_error( $con ) );
								$row12 = mysqli_fetch_array( $result12 );
								?>
								<span class="info-box-number">
									<?php echo $row12['count(*)']; ?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-yellow"><i class="ion ion-ios-personadd-outline"></i></span>
							<?php
							$sql13 = "select count(*) from faculty";
							$result13 = mysqli_query( $con, $sql13 )or die( mysqli_error( $con ) );
							$row13 = mysqli_fetch_array( $result13 );
							?>
							<div class="info-box-content">
								<span class="info-box-text">All Faculty</span>
								<span class="info-box-number">
									<?php echo $row13['count(*)'];?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->
				<!-- Main row -->
				<div class="row">
					<div class="col-xs-12">
						<div class="box">
							<div class="box-header">
								<h3 class="box-title">Your Feedback 
			   <?php echo "For Month Of ".date('M, Y');?></h3>
								<div class="box-tools pull-right">
									<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
									<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
								</div>
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<form class="" method="post" action="feedback.php">
									<table class="table table-bordered table-responsive">
										<thead>
											<tr align="center">
												<th>
													<center>Sr.No</center>
												</th>
												<th>
													<center>Statements</center>
												</th>
												<th>
													<center>Always</center>
												</th>
												<th>
													<center>Often</center>
												</th>
												<th>
													<center>Sometimes</center>
												</th>
												<th>
													<center>Occasionally</center>
												</th>
												<th>
													<center>Rarely</center>
												</th>
											</tr>
										</thead>
										<tbody>
											<?php 
							    $sql = "select max(date_id) as id from date";
								$result = mysqli_query($con,$sql);
								$row = mysqli_fetch_array($result);
								$date_id = $row['id'];
								$num_rec_per_page=1;
								if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1;}; 
									$start_from = ($page-1) * $num_rec_per_page; 
									$sql = "SELECT *  FROM courses where cour_dept ='".$row0['Dept_Id']."' and cour_sem='".$row0['Semester_Id']."' and cour_faculty is not null"; 
									$rs_result = mysqli_query($con,$sql); //run the query
									$total_records = mysqli_num_rows($rs_result);  //count number of records
									$total_pages = ceil($total_records / $num_rec_per_page); 									
									$sql = "SELECT * FROM courses where cour_dept = '$dept_id' and cour_sem='".$row0['Semester_Id']."' and cour_faculty is not null LIMIT $start_from, $num_rec_per_page"; 
									//$sql="Select * from courses where not exists(select * from feedback where feed_course_id=courses.cour_id and feed_enroll_id='$rollno')and courses.cour_dept='$dept_id' and cour_faculty is not null LIMIT $start_from, $num_rec_per_page";
									$rs_result = mysqli_query ($con,$sql); //run the query 
									$i=0; //counter variable									
									foreach($rs_result as $row) 
									{ 
									?>
											<input type="hidden" value="<?php echo $row['Cour_Id'];?>" name="course" id="course"/><b><strong><?php echo $row['Cour_Name'];?></strong></b>
											<input type="hidden" value="<?php echo $rollno ?>" name="rollno" id="rollno"/>
											<div id="feed"></div>
											<tr>
												<td align="center">1</td>
												<td>Is the teacher punctual in taking his/her classes?</td>
												<td align="center">
													<label><input type="radio" name="one" id="one"  value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="one" id="one" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="one" id="one" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="one" id="one" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="one" id="one" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">2</td>
												<td>Does your teacher come prepared for teaching?</td>
												<td align="center">
													<label><input type="radio" name="two" id="two" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="two" id="two" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="two" id="two" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="two" id="two" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="two" id="two" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">3</td>
												<td>Are the explanation of subject by the teacher clear and understandable?</td>
												<td align="center">
													<label><input type="radio" name="three" id="three" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="three" id="three" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="three" id="three" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="three" id="three" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="three" id="three" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">4</td>
												<td>Does the teacher respond well to the question asked by the student?</td>
												<td align="center">
													<label><input type="radio" name="four" id="four" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="four" id="four" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="four" id="four" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="four" id="four" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="four" id="four" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">5</td>
												<td>Do you feel motivated to learn during his/her classes?</td>
												<td align="center">
													<label><input type="radio" name="five" id="five" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="five" id="five" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="five" id="five" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="five" id="five" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="five" id="five" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">6</td>
												<td>Does the teacher maintain discpline in the class?</td>
												<td align="center">
													<label><input type="radio" name="six" id="six" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="six"  id="six" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="six"  id="six" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="six"  id="six" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="six"  id="six" value="1"> 1 </label>
												</td>
											</tr>
											<tr>
												<td align="center">7</td>
												<td>Does the teacher complete the syllabus of the subject?</td>
												<td align="center">
													<label><input type="radio" name="seven" id="seven" value="5"> 5 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="seven" id="seven" value="4"> 4 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="seven" id="seven" value="3"> 3 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="seven" id="seven" value="2"> 2 </label>
												</td>
												<td align="center">
													<label><input type="radio" name="seven" id="seven" value="1"> 1 </label>
												</td>
											</tr>
											<div class="form-actions">
												<?php 
														if($page>1)
														{
															$n=$page-1;
															$url = "feedback.php?page=".$n;
															echo "<a href=\"$url\" class='btn btn-warning' style='width:60px;margin-left:86.2%;'><i Class='fa fa-angle-left fa-2x'></i></a>\n";
														} 
														// page numbering links now	
														if ($page < $total_pages) 
														{
															$n=$page+1;
															$url = "feedback.php?page=".$n;
															echo "<a href=\"$url\" class='btn btn-primary' style='width:60px;'><i Class='fa fa-angle-right fa-2x'></i></a>\n";
														}														
													?>
											</div>
											<?php
											$i++; //Increment Counter Variable
											}
											?>
										</tbody>
									</table>
									<textarea name="commit" id="commit" rows="3" cols="100" style="width:100%;overflow:none;border:none;" placeholder="Any Suggestions"></textarea>
									<input type="hidden" name="rows" id="rows" value="<?php echo $i; ?>"/>
									<button type="button" name="submit" id="submit" class="btn btn-success">Give Feedback</button>
								</form>
							</div>
							<!-- /.box-body -->

						</div>
						<!-- /.box -->
					</div>
				</div>
				<!-- /.row -->
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		<footer class="main-footer">
			<div class="pull-right hidden-xs">
				<a href="https://www.facebook.com/erpadroo.sajad" target="_blank"><i class="fa fa-facebook-official " style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
				<a href="https://www.youtube.com/channel/UCuatnXHBmaQqo3GD9k20asA" target="_blank"><i class="fa fa-youtube-play text-red" style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
			</div>
			<strong>Copyright &copy; 2015-2017 <a href="https://">Sajad Ahmad Padroo</a>.</strong> All rights reserved.
		</footer>
		<?php include"../Php_Include/For_Students/Profile_Modal_Student.php";?>
		<!-- Control Sidebar -->
		<aside class="control-sidebar control-sidebar-dark">

			<!-- Tab panes -->
			<div class="tab-content">
				<!-- Home tab content -->
				<div class="tab-pane" id="control-sidebar-home-tab">
				</div>
				<!-- /.tab-pane -->
				<!-- Settings tab content -->
				<div class="tab-pane" id="control-sidebar-settings-tab">
				</div>
				<!-- /.tab-pane -->
			</div>
		</aside>
		<!-- /.control-sidebar -->
		<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
		<div class="control-sidebar-bg"></div>
	</div>
	<!-- ./wrapper -->
	<?php 
require("../Php_Include/Header_Footer_Files/Footer_Include.php");												
require("../Php_Include/For_Students/StudentProfile.php");
?>
	<script>
		$( document ).ready( function () {
			$( "#submit" ).click( function () {
				var course = $( "#course" ).val();
				var rollno = $( "#rollno" ).val();
				var one = $( "#one:checked" ).val();
				var two = $( "#two:checked" ).val();
				var three = $( "#three:checked" ).val();
				var four = $( "#four:checked" ).val();
				var five = $( "#five:checked" ).val();
				var six = $( "#six:checked" ).val();
				var seven = $( "#seven:checked" ).val();
				var commit = $( '#commit' ).val();
				$.ajax( {
					type: "post",
					url: "../Php_Include/For_Students/SaveFeedback.php",
					data: {
						course: course,
						rollno: rollno,
						one: one,
						two: two,
						three: three,
						four: four,
						five: five,
						six: six,
						seven: seven,
						commit: commit
					},
					success: function ( data ) {
						$( "#feed" ).html( data );
					}
				} );
			} );
		} );
		$( document ).ready( function () {
			$( "#changepassword" ).click( function () {
				var password = $( "#password" ).val();
				var roll = $( "#roll" ).val();
				$.ajax( {
					type: "post",
					url: "../Php_Include/For_Students/Change_Password.php",
					data: {
						password: password,
						roll: roll
					},
					success: function ( data ) {
						$( "#fun" ).html( data );
						document.getElementById( "password" ).value = '';
						window.location.href = "students.php";
					}
				} );
			} );
		} );
	</script>
</body>

</html>