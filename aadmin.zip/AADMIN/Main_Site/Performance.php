<?php
session_start();
if(!isset($_SESSION['email']))
	header('Location:../');
	include '../Php_Include/dbcon.php';
	$path = "Uploads/";
	$username=$_SESSION['email'];
	$sql0="select * from faculty where Fac_email='$username'";
	$result0 = mysqli_query($con,$sql0) or die(mysqli_error($con));
	$row0 = mysqli_fetch_array($result0);
	$hod_id=$row0['Fac_Id'];
	$fac_id=$row0['Fac_Id'];
	$hod_name=$row0['Fac_Name'];
	$sql = "SELECT * FROM departments WHERE dept_hod = '$hod_id'";
		$result = mysqli_query($con,$sql) or die(mysqli_error($con));
		$row3 = mysqli_fetch_array($result);
		$dept_id=$row3['Dept_Id'];	
		$sql = "SELECT count(*) FROM departments";
		$result = mysqli_query($con,$sql) or die(mysqli_error($con));
		$row00 = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo ucwords($hod_name);?>'s | Dashboard</title>
    <?php include "../Php_Include/Header_Footer_Files/Header_Include.php" ;?>
</head>
<?php include "../Php_Include/Common/Change_Profile_Picture.php"?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>S</b>PS</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Performance</b> System</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
			  <img src="<?php echo $path.$row0['Img_Name'];?>" alt="Pic" class="user-image" />
              <span class="hidden-xs"><?php echo($hod_name);?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo $path.$row0['Img_Name'];?>" alt="Pic" class="img-circle" />
				<button type="button" name="add" id="add" class="btn btn-success"><i class="fa fa-pencil"></i></button>
                <p>
                  <?php echo ucwords($hod_name);?>
                  <small>HoD <?php echo ucwords($row3['Dept_Name']);?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a data-toggle="modal" data-target="#profile" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="../Php_Include/Logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>

    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active"><a href="Head_Of_Departments.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-plus"></i>
            <span>Additions</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a data-toggle="modal" data-target="#addfaculty"><i class="fa fa-circle-o"></i> Faculty</a></li>
            <li><a data-toggle="modal" data-target="#addcourse"><i class="fa fa-circle-o"></i> Cources</a></li>
            <li><a data-toggle="modal" data-target="#addstudent"><i class="fa fa-circle-o"></i> Students</a></li>
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-upload"></i>
            <span>Semester Upgrade</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
		  <?php
		    $sqli = "SELECT * FROM semesters WHERE  dept_id ='$dept_id'";
			$resulti = mysqli_query($con,$sqli) or die(mysqli_error($con));
			while($rowi = mysqli_fetch_array($resulti)) {
           echo' <li><a href="Semesters.php?id='.$rowi['Sem_Id'].'"><i class="fa fa-circle-o"></i>'.' '.$rowi['Sem_Name'].' '.'</a></li>';
              }?>
          </ul>
        </li>       
		<li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Attendence Report</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
		  <?php
		    $sqli = "SELECT * FROM semesters WHERE  dept_id ='$dept_id' order by sem_id ASC";
			$resulti = mysqli_query($con,$sqli) or die(mysqli_error($con));
			while($rowi = mysqli_fetch_array($resulti)) {
           echo' <li><a href="Attendence_Report.php?id='.$rowi['Sem_Id'].'"><i class="fa fa-circle-o"></i>'.' '.$rowi['Sem_Name'].' '.'</a></li>';
              }?>
          </ul>
        </li> 
<li class="treeview">
						<a href="#">
											<i class="fa fa-tasks"></i>
											<span>Acedemic Review</span>
											<span class="pull-right-container">
												 <i class="fa fa-angle-left pull-right"></i>
											</span>
										</a>
					
						<ul class="treeview-menu">
							<?php
							$sqli = "SELECT  * FROM semesters WHERE dept_id='$dept_id'  order by sem_id ASC";
							$resulti = mysqli_query( $con, $sqli )or die( mysqli_error( $con ) );
							while ( $rowi = mysqli_fetch_array( $resulti ) ) {
								?>
							<li class="treeview">
									<a href="#">
										<i class="fa fa-circle-o text-green"></i>
										<span><?php echo $rowi[ 'Sem_Name' ];?></span>
										<span class="pull-right-container">
											<i class="fa fa-angle-left pull-right"></i>
										</span>
									</a>
									<ul class="treeview-menu">
										<?php
										$sqlw = "SELECT  * FROM courses WHERE cour_sem='".$rowi['Sem_Id']."'  order by cour_id ASC";
										$resultw = mysqli_query( $con, $sqlw )or die( mysqli_error( $con ) );
										while($roww = mysqli_fetch_array( $resultw )){
											echo '																						
											<li style="overflow:hidden;"><a href="Acedemic_Review.php?id=' . $roww[ 'Cour_Id' ] . '"><i class="fa fa-circle-o"></i>' . ' ' . $roww[ 'Cour_Name' ] . ' ' . '</a></li>';
										}								
										echo '
								    </ul>
							</li>';
							}
							?>
						</ul>						
					</li>		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-comments "></i>
            <span>FeedBack Check</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
		  <?php
		    $sqli = "SELECT * FROM semesters WHERE  dept_id ='$dept_id' order by sem_id ASC";
			$resulti = mysqli_query($con,$sqli) or die(mysqli_error($con));
			while($rowi = mysqli_fetch_array($resulti)) {
           echo' <li><a href="FeedBack_Report.php?id='.$rowi['Sem_Id'].'"><i class="fa fa-circle-o"></i>'.' '.$rowi['Sem_Name'].' '.'</a></li>';
              }?>
          </ul>
        </li>
		<li><a href="SMS_Service.php"><i class="fa fa-envelope"></i> <span>SMS Services</span></a></li>			
        <li class="header">LABELS</li>
        <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a></li>
        <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a></li>
        <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php include"../Php_Include/Hod_Page_Modal/Student_Modal.php"?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li class="active">Performamce</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-home-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">No. Of Departments</span>
              <span class="info-box-number"><?php echo $row00['count(*)'];?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>
                            <?php
								$sql11 = "select count(*) from students";
								$result11 = mysqli_query($con,$sql11) or die(mysqli_error($con));
								$row11 = mysqli_fetch_array($result11);
							?>
            <div class="info-box-content">
              <span class="info-box-text">Total Students Of College</span>
              <span class="info-box-number"><?php echo $row11['count(*)']; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-book-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Result Entries</span>
			                <?php
								$sql12 = "select count(*) from exam_performance";
								$result12 = mysqli_query($con,$sql12) or die(mysqli_error($con));
								$row12 = mysqli_fetch_array($result12);
							?>
              <span class="info-box-number"><?php echo $row12['count(*)']; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-personadd-outline"></i></span>
                            <?php
								$sql13 = "select count(*) from faculty";
								$result13 = mysqli_query($con,$sql13) or die(mysqli_error($con));
								$row13 = mysqli_fetch_array($result13);
							?>
            <div class="info-box-content">
              <span class="info-box-text">All Faculty</span>
              <span class="info-box-number"><?php echo $row13['count(*)'];?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <!-- interactive chart -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-bar-chart-o"></i>
              <h3 class="box-title">Bar Chart</h3>
			  <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div id="bar-chart" style="height: 300px;"></div>
            </div>
            <!-- /.box-body-->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
			   <?php
					if(isset($_GET['id']))
						$rollno = $_GET['id'];
						$sql0="select * from students where Rollno='$rollno'";
						$result0 = mysqli_query($con,$sql0) or die(mysqli_error($con));
						$row0 = mysqli_fetch_array($result0);
						$stud_name=$row0['Name'];
						$stud_dept=$row0['Dept_Id'];
						
				?>
						
						<?php 
								$sql = "SELECT * FROM semesters WHERE  dept_id ='$dept_id'";
								$result = mysqli_query($con,$sql) or die(mysqli_error($con));
								while($row2 = mysqli_fetch_array($result)) {	
						?>	
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo ucwords($stud_name);?>'s  Acedemic Performance(<?php echo $row2['Sem_Name'];?> Semester)</h3>
			  <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th class="center">SUBJECT NAME</th>
					<th class="center">SESSIONAL MARKS</th>
					<th class="center">PRACTICAL MARKS</th>
					<th class="center">THEORY MARKS</th> 
					<th class="center">TOTAL MARKS</th> 
                </tr>
                </thead>
                <tbody>
								<?php
									$sql1 = "select * from exam_performance where Student_Rollno = '$rollno' and Sem_Id='".$row2['Sem_Id']."'";
									$result1 = mysqli_query($con,$sql1) or die(mysqli_error($con));
									while($row1 = mysqli_fetch_array($result1)) {	
								?>
								<tr>
												<td><?php echo $row1['Subject_Name']; ?></td>
												<td class="center">
													<?php echo $row1['Sessional_Marks']; ?>
												</td>
												<td class="center">
													<?php echo $row1['Practical_Marks']; ?>
												</td>
												<td class="center">
													<?php echo $row1['Theory_Marks']; ?>
												</td>
												<td class="center">
													<?php echo $row1['Theory_Marks']+$row1['Practical_Marks']+$row1['Sessional_Marks']; ?>
												</td>                                       
								</tr>
											<?php
												}
											?>
		
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
      </div>
	  <?php
						}
					?>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
    <!-- /.content-wrapper -->
<?php include"../Php_Include/Hod_Page_Modal/Course_Modal.php";?>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
     <a href="https://www.facebook.com/erpadroo.sajad" target="_blank"><i class="fa fa-facebook-official " style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
	 <a href="https://www.youtube.com/channel/UCuatnXHBmaQqo3GD9k20asA" target="_blank"><i class="fa fa-youtube-play text-red" style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
    </div>
    <strong>Copyright &copy; 2015-2017 <a href="https://">Sajad Ahmad Padroo</a>.</strong> All rights reserved.
  </footer>
<?php include"../Php_Include/Hod_Page_Modal/Hod_Profile_Modal.php";?>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">

    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php 
require("../Php_Include/Header_Footer_Files/Footer_Include.php");												
require("../Php_Include/Common/Profile_Pic_Modal.php");
?>
<script>
  $(function () {
     /*
     * BAR CHART
     * ---------
     */
    var bar_data = {
      data : [['January', 10], ['February', 8], ['March', 4], ['April', 13], ['May', 17], ['June', 9]],
      color: '#3c8dbc'
    }
    $.plot('#bar-chart', [bar_data], {
      grid  : {
        borderWidth: 1,
        borderColor: '#f3f3f3',
        tickColor  : '#f3f3f3'
      },
      series: {
        bars: {
          show    : true,
          barWidth: 0.5,
          align   : 'center'
        }
      },
      xaxis : {
        mode      : 'categories',
        tickLength: 0
      }
    })
    /* END BAR CHART */

  })
  /*
   * Custom Label formatter
   * ----------------------
   */
  function labelFormatter(label, series) {
    return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">'
      + label
      + '<br>'
      + Math.round(series.percent) + '%</div>'
  }
</script>
<script src="../Php_Include/Hod_Page_Files/SearchAll.js"></script>	
<?php include "../Php_Include/Hod_Page_Modal/Faculty_Modal.php";?>	
</body>
</html>
