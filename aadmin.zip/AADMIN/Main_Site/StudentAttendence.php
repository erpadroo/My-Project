<?php
session_start();
if ( !isset( $_SESSION[ 's_email' ] ) )
	header( 'Location:../' );
$path = "Uploads/";
include '../Php_Include/dbcon.php';
$username = $_SESSION[ 's_email' ];
$sql0 = "select * from students where rollno='$username'";
$result0 = mysqli_query( $con, $sql0 )or die( mysqli_error( $con ) );
$row0 = mysqli_fetch_array( $result0 );
$rollno = $row0[ 'Rollno' ];
$student_name = $row0[ 'Name' ];
$sql = "SELECT * FROM departments WHERE dept_id = '" . $row0[ 'Dept_Id' ] . "'";
$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
$row3 = mysqli_fetch_array( $result );
$dept_id = $row3[ 'Dept_Id' ];
$sql = "SELECT count(*) FROM departments";
$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
$row00 = mysqli_fetch_array( $result );
?>
<!DOCTYPE html>
<html>

<head>
	<title>
		<?php echo ucwords($student_name);?>'s | Dashboard</title>
	<?php include ("../Php_Include/Header_Footer_Files/Header_Include.php") ;?>
</head>
<?php include ("../Php_Include/For_Students/StudentAction.php");?>

<body class="hold-transition skin-blue sidebar-mini" onLoad="document.forms.search.part.focus()">
	<div class="wrapper">
		<header class="main-header">
			<!-- Logo -->
			<a href="#" class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><img src="../img/logo_s.jpg" style="width:50px;height:50px;" /></span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg" style="height:auto;width:auto;"><img src="../img/logo_l.png" style="height:50px;width:100%;margin-left:0px;margin-top:-8px;margin-right:0px" /></span>
			</a>

			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
			
				<!-- Navbar Right Menu -->
				<div class="navbar-custom-menu">
					<ul class="nav navbar-nav">
						<!-- User Account: style can be found in dropdown.less -->
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
			  <img src="<?php echo $path.$row0['Photo'];?>" alt="Pic" class="user-image" />
              <span class="hidden-xs"><?php echo($student_name);?></span>
            </a>
						
							<ul class="dropdown-menu">
								<!-- User image -->
								<li class="user-header">
									<img src="<?php echo $path.$row0['Photo'];?>" alt="Pic" class="img-circle"/>
									<button type="button" name="add" id="add" class="btn btn-success"><i class="fa fa-pencil"></i></button>
									<p>
										<?php echo ucwords($student_name);?>
										<small>Student of <?php echo ucwords($row3['Dept_Name']);?></small>
									</p>
								</li>
								<!-- Menu Footer-->
								<li class="user-footer">
									<div class="pull-left">
										<a data-toggle="modal" data-target="#profile" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right">
										<a href="../Php_Include/Logout.php" class="btn btn-default btn-flat">Sign out</a>
									</div>
								</li>
							</ul>
						</li>
						<!-- Control Sidebar Toggle Button -->
						<li>
							<a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
						</li>
					</ul>
				</div>

			</nav>
		</header>
		<!-- Left side column. contains the logo and sidebar -->
		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				<!-- search form -->
				<form action="#" method="get" class="sidebar-form">
					<div class="input-group">
						<input type="text" name="q" class="form-control" placeholder="Search...">
						<span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
					
					</div>
				</form>
				<!-- /.search form -->
				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu" data-widget="tree">
					<li><a href="Students.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a>
					</li>
					<li><a href="Feedback.php"><i class="fa fa-circle"></i><span>Feedback</span></a>
					</li>
					<li class="active"><a href="StudentAttendence.php"><i class="fa fa-envelope"></i> <span>Attendence</span></a>
					</li>
					<li class="header">LABELS</li>
					<li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a>
					</li>
					<li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a>
					</li>
					<li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a>
					</li>
				</ul>
			</section>
			<!-- /.sidebar -->
		</aside>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
			
				<ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> Home</a>
					</li>
					<li class="active">Dashboard</li>
				</ol>
			</section>
			<?php
			if ( isset( $error0 ) )echo '<div class="box-header" ><p style="text-align:center;color:red;" >Operation Failed Please Try Again</p></div> ';
			if ( isset( $error1 ) )echo '<div class="box-header" ><p style="text-align:center;color:red;" >Operation Failed Please Try Again</p></div> ';
			if ( isset( $error ) )echo '<div class="box-header" ><p style="text-align:center;color:red;" >Already Exist</p>	</div> ';
			if ( isset( $success ) )echo '<div class="box-header" ><p style="text-align:center;color:green;">Added Successfully..!</p></div> ';
			if ( isset( $success1 ) )echo '<div class="box-header" ><p style="text-align:center;color:green;">Password Changed Successfully..!</p></div> ';
			if ( isset( $success2 ) )echo '<div class="box-header" ><p style="text-align:center;color:green;">Profile Picture Changed Successfully..!</p></div> ';
			?>
			<!-- Main content -->
			<section class="content">
				<!-- Info boxes -->
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-aqua"><i class="ion ion-ios-home-outline"></i></span>

							<div class="info-box-content">
								<span class="info-box-text">No. Of Departments</span>
								<span class="info-box-number">
									<?php echo $row00['count(*)'];?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>
							<?php
							$sql11 = "select count(*) from students where Semester_id= '" . $row0[ 'Semester_Id' ] . "'";
							$result11 = mysqli_query( $con, $sql11 )or die( mysqli_error( $con ) );
							$row11 = mysqli_fetch_array( $result11 );
							?>
							<div class="info-box-content">
								<span class="info-box-text">Total Students Of College</span>
								<span class="info-box-number">
									<?php echo $row11['count(*)']; ?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<!-- fix for small devices only -->
					<div class="clearfix visible-sm-block"></div>

					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-green"><i class="ion ion-ios-book-outline"></i></span>

							<div class="info-box-content">
								<span class="info-box-text">Total Result Entries</span>
								<?php
								$sql12 = "select count(*) from exam_performance where Student_Rollno='$rollno'";
								$result12 = mysqli_query( $con, $sql12 )or die( mysqli_error( $con ) );
								$row12 = mysqli_fetch_array( $result12 );
								?>
								<span class="info-box-number">
									<?php echo $row12['count(*)']; ?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="info-box">
							<span class="info-box-icon bg-yellow"><i class="ion ion-ios-personadd-outline"></i></span>
							<?php
							$sql13 = "select count(*) from faculty";
							$result13 = mysqli_query( $con, $sql13 )or die( mysqli_error( $con ) );
							$row13 = mysqli_fetch_array( $result13 );
							?>
							<div class="info-box-content">
								<span class="info-box-text">All Faculty</span>
								<span class="info-box-number">
									<?php echo $row13['count(*)'];?>
								</span>
							</div>
							<!-- /.info-box-content -->
						</div>
						<!-- /.info-box -->
					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->
				<!-- Main row -->
				<?php 
								$sql = "SELECT * FROM semesters WHERE  dept_id ='$dept_id'";
								$result = mysqli_query($con,$sql) or die(mysqli_error($con));
								while($row2 = mysqli_fetch_array($result)) {	
						?>
				<div class="row">
					<div class="col-xs-12">
						<div class="box">
							<div class="box-header">
								<h3 class="box-title">
									<?php echo $row2['Sem_Name'];?> Semester</h3>
								<div class="box-tools pull-right">
									<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
									<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
								</div>
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<table id="example2" class="table table-bordered table-hover">
									<thead>
										<tr>
											<th class="center">ROLL NUMBER</th>
											<th class="center">STUDENT NAME</th>
											<th class="center">SUBJECT NAME</th>
											<th class="center">CLASSES ATTENDED</th>
											<th class="center">TOTAL CLASSES</th>
											<th class="center">ATTENDENCE PERCENTAGE</th>
											<th class="center">FROM DATE - TO DATE </th>
										</tr>
									</thead>
									<tbody>
										<?php
										$sql1 = "select * from attendence where Sem_Id = '" . $row2[ 'Sem_Id' ] . "' and Rollno='$rollno'";
										$result1 = mysqli_query( $con, $sql1 )or die( mysqli_error( $con ) );
										while ( $row1 = mysqli_fetch_array( $result1 ) ) {
											?>
										<tr>
											<td>
												<?php echo $row1['Rollno']; ?>
											</td>
											<td class="center">
												<?php echo $row1['Name']; ?>
											</td>
											<td class="center">
												<?php echo $row1['Subject_Name']; ?>
											</td>
											<td class="center">
												<?php echo $row1['Classes_Attended']; ?>
											</td>
											<td class="center">
												<?php echo $row1['Total_Classes']; ?>
											</td>
											<td class="center">
												<?php echo round(($row1['Classes_Attended']/$row1['Total_Classes'])*100);?>%
											</td>
											<td class="center">
												<?php echo $row1['Start_Date'].'/'.$row1['End_Date'];?>
											</td>
										</tr>
										<?php
										}
										?>
									</tbody>
								</table>
							</div>
							<!-- /.box-body -->

						</div>
						<!-- /.box -->
					</div>
				</div>
				<?php
				}
				?>
				<!-- /.row -->
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		<footer class="main-footer">
			<div class="pull-right hidden-xs">
				<a href="https://www.facebook.com/erpadroo.sajad" target="_blank"><i class="fa fa-facebook-official " style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
				<a href="https://www.youtube.com/channel/UCuatnXHBmaQqo3GD9k20asA" target="_blank"><i class="fa fa-youtube-play text-red" style="font-size:30px;height:35px;width:35px;line-height:35px;border-radius:30px;text-align:center;"></i></a>
			</div>
			<strong>Copyright &copy; 2015-2017 <a href="https://">Sajad Ahmad Padroo</a>.</strong> All rights reserved.
		</footer>
		<?php include"../Php_Include/For_Students/Profile_Modal_Student.php";?>
		<!-- Control Sidebar -->
		<aside class="control-sidebar control-sidebar-dark">

			<!-- Tab panes -->
			<div class="tab-content">
				<!-- Home tab content -->
				<div class="tab-pane" id="control-sidebar-home-tab">
				</div>
				<!-- /.tab-pane -->
				<!-- Settings tab content -->
				<div class="tab-pane" id="control-sidebar-settings-tab">
				</div>
				<!-- /.tab-pane -->
			</div>
		</aside>
		<!-- /.control-sidebar -->
		<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
		<div class="control-sidebar-bg"></div>
	</div>
	<!-- ./wrapper -->
	<?php
	require( "../Php_Include/Header_Footer_Files/Footer_Include.php" );
	require( "../Php_Include/For_Students/StudentProfile.php" );
	?>
	<script type="text/javascript">
		$( document ).ready( function () {
			$( "#changepassword" ).click( function () {
				var password = $( "#password" ).val();
				var roll = $( "#roll" ).val();
				$.ajax( {
					type: "post",
					url: "../Php_Include/For_Students/Change_Password.php",
					data: {
						password: password,
						roll: roll
					},
					success: function ( data ) {
						$( "#fun" ).html( data );
						document.getElementById( "password" ).value = '';
						window.location.href = "students.php";
					}
				} );
			} );
		} );
	</script>
</body>

</html>