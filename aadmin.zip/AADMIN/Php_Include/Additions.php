<?php
				    include_once "dbcon.php";
                    if(isset($_POST['course_id'])){
					    $course_id = $_POST['course_id'];
						$course_name = $_POST['course_name'];
						$dept_id = $_POST['dept_id'];
						$sem_id = $_POST['sem_id'];
						$faculty_id = $_POST['faculty_id'];
						$sqlc="select * from courses where cour_id='$course_id'";
						$result=mysqli_query($con,$sqlc)or die();
						$numrows=mysqli_num_rows($result);
						if($numrows==1)
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Course Already Exists</p>";
							}
						else
						{
							$sql="insert into courses (Cour_Id,Cour_Name,Cour_Dept,Cour_Faculty,Cour_Sem) VALUES ('$course_id','$course_name','$dept_id','$faculty_id','$sem_id')";
							if(mysqli_query($con,$sql))
							{
								echo"<p class='alert alert-success' style='text-align:center'>Course Inserted Successfully</p>";
							}
							else
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
							}
						}	
		            }
					if(isset($_POST['f_id'])){
						$fac_id=$_POST['f_id'];
						$fac_name=$_POST['ff_name'];
						$fac_contact=$_POST['f_phone'];
						$fac_email=$_POST['f_email'];
						$fac_address=$_POST['f_address'];
						//$fac_pass=$_POST['f_pass'];
						$sqlc="select * from faculty where fac_id='$fac_id'";
						$result=mysqli_query($con,$sqlc)or die();
						$numrows=mysqli_num_rows($result);
						if($numrows==1)
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Faculty Already Exists</p>";
							}
						else
						{    
							$string = "";
							$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
							for($i=0;$i<10;$i++)
							$string.=substr($chars,rand(0,strlen($chars)),1);
							$sql="insert into faculty(Fac_id,Fac_name,Fac_contact,Fac_email,Fac_address,Fac_password,Img_Name) values ('$fac_id','$fac_name','$fac_contact','$fac_email','$fac_address','$string','')";
							if(mysqli_query($con,$sql))
							{
								$subject="Password For Login To Surya World Systems";
								$headers="Psajad17@gmail.com";
								if(mail($fac_email,$subject,"Your Login Details Is:\nEmail Id: ".$fac_email."\nPassword: ".$string."\nThanks And Best Regards\nSurya World College",$headers)){
								echo"<p class='alert alert-success' style='text-align:center'>Faculty Inserted Successfully</p>";
								}
							}
							else
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
							}
						}		
					}
					if(isset($_POST['uni_roll']))
					{
						$uni_roll = $_POST['uni_roll'];
						$student_name = $_POST['student_name'];
						$dept_id = $_POST['dept_id'];
						$sem_idd = $_POST['sem_idd'];
						$contact = $_POST['contact'];
						$dob = $_POST['dob'];
						$dob1 = strtotime("$dob");
						$dob2 = date('Y-m-d', $dob1);
						$f_name= $_POST['f_name'];
						$f_contact= $_POST['f_contact'];
						$m_name= $_POST['m_name'];
						$s_email= $_POST['s_email'];
						$p_address= $_POST['p_address'];
						$c_address= $_POST['c_address'];						
						$sqlc="select * from students where Rollno='$uni_roll'";
						$result=mysqli_query($con,$sqlc)or die();
						$numrows=mysqli_num_rows($result);
						if($numrows==1)
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Student Already Exists</p>";
							}
						else
						{
							$sql="insert into students (Rollno,Name,Semester_Id,Contact,Date_Of_Birth,Fathers_Name,Fathers_Contact,Mothers_Name,Email,Password,Perment_Address,Corres_Address,dept_id) VALUES ('$uni_roll','$student_name','$sem_idd','$contact','$dob2','$f_name','$f_contact','$m_name','$s_email','','$p_address','$c_address','$dept_id')";
							if(mysqli_query($con,$sql)){
							echo"<p class='alert alert-success' style='text-align:center'>Student Inserted Successfully</p>";							
							}
							else
							{ 
						die(mysqli_error($con));
								//echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
							}
					    }
					}
				if(isset($_POST['semester'])){
						$semester=$_POST['semester'];
						$rollno=$_POST['sroll'];
						if($semester!='')
						{							
							$sql="update students set Semester_Id='$semester' where rollno='$rollno'";
							if(mysqli_query($con,$sql))
							{
								echo"<p class='alert alert-success' style='text-align:center'>Semester Upgraded Successfully</p>";
							}
							else
							{
								echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong</p>";
							}
						}
						else
						{
							$date=date('Y');
							$queryCreateUsersTable = "CREATE TABLE IF NOT EXISTS Passouts".$date."(
								`Rollno` varchar(50) NOT NULL,
								`Name` varchar(50) NOT NULL,
								`Phone_Number` bigint(12) NOT NULL,
								`Email` varchar(50) NOT NULL,
								`DOB` date NOT NULL,
								`Fathers_Name` varchar(50) NOT NULL,
								`Mothers_Name` varchar(50) NOT NULL ,
								`Branch` varchar(50) NOT NULL,								
								`Passout_Year` varchar(20) NOT NULL,								
								`Photo` varchar(500) NOT NULL,								
								 PRIMARY KEY  (`Rollno`),
								 foreign key(Branch) references departments(dept_id)
							)";		
							mysqli_query($con,$queryCreateUsersTable);
							$sql="select * from students where rollno='$rollno'";
							$result=mysqli_query($con,$sql);
							$numrows=mysqli_num_rows($result);
							if($numrows>0)
							{
								$sql2="select * from students where rollno='$rollno'";
								$result2=mysqli_query($con,$sql2);
								while($row=mysqli_fetch_array($result2))
								{
									$sql3="insert into passouts".$date."(Rollno,Name,Phone_Number,Email,DOB,Fathers_Name,Mothers_Name,Branch,Passout_Year,Photo)
									Values('".$row['Rollno']."','".$row['Name']."','".$row['Contact']."',
									'".$row['Email']."','".$row['Date_Of_Birth']."','".$row['Fathers_Name']."',
									'".$row['Mothers_Name']."','".$row['Dept_Id']."','".$date."','".$row['Photo']."')";
									mysqli_query($con,$sql3);
									$sql="delete from students where rollno='$rollno'";
									mysqli_query($con,$sql);
								}
							}
						}
					}					
                 					
?>