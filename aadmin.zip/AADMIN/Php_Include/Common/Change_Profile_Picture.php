<?php
// Check if image file is a actual image or fake image
if ( isset( $_POST[ "insert" ] ) ) {
	include( "../Php_Include/Dbcon.php" );
	$id = $_POST[ 'id' ];
	$sql = "select img_name from faculty where fac_id='$id'";
	$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
	$row = mysqli_fetch_array( $result );
	if ( $row[ 'img_name' ] == '' ) {
		$target_dir = "Uploads/";
		$target_file = $target_dir . basename( $_FILES[ "image" ][ "name" ] );
		$uploadOk = 1;
		$imageFileType = pathinfo( $target_file, PATHINFO_EXTENSION );
		$check = getimagesize( $_FILES[ "image" ][ "tmp_name" ] );
		// Check if file already exists
		if ( file_exists( $target_file ) ) {
			?>
			<script>
				alert( "Sorry, file already exists." );
			</script>
			<?php
			$uploadOk = 0;
		}
		// if everything is ok, try to upload file
		else {
			if ( move_uploaded_file( $_FILES[ "image" ][ "tmp_name" ], $target_file ) ) {
				$target_path = basename( $_FILES[ "image" ][ "name" ] ); // used to store the filename in a variable
				//storing the data in your database
				$query = "update faculty set img_name='$target_path' where fac_id='$id'";
				if ( mysqli_query( $con, $query ) ) {
					?>
					<script>
						alert( "Your Profile has been Updated, page will refresh in 3 seconds.... to take effects" );
						window.location.href = document.URL;
					</script>
					<?php
					//header( "Refresh:3; url=", true, 303);
				} else {
					die( mysqli_error( $con ) );
				}
			} else {
				?>
				<script>
					alert( "Sorry, there was an error uploading your file." );
				</script>
				<?php
			}
		}
	} else {
		?>
		<script>
			alert( "You Have Already Set Your Profile." );
		</script>
		<?php

	}
}
if ( isset( $_POST[ 'changepassword' ] ) ) {
	$password = $_POST[ 'password' ];
	$sql = "update faculty set Fac_Password='$password' where Fac_Id='$fac_id'";
	if ( mysqli_query( $con, $sql ) ) {
		$success1 = true;
	} else {
		$error1 = true;
	}
}
if ( isset( $_POST[ 'changehodpassword' ] ) ) {

	$password = $_POST[ 'password' ];
	$sql = "update departments set Hod_Password='$password' where Dept_Hod='$hod_id'";
	if ( mysqli_query( $con, $sql ) ) {
		$success1 = true;
	} else {
		$error1 = true;
	}
}
?>