<?php
require( "../dbcon.php" );
if ( isset( $_POST[ 'password' ] ) ) {
	$password = $_POST[ 'password' ];
	$rollno = $_POST[ 'roll' ];
	$sql = "update departments set Hod_Password='$password' where dept_hod='$rollno'";
	if ( mysqli_query( $con, $sql ) ) {
		echo "<p class='alert alert-success' style='text-align:center'>Password Changed Successfully</p>";
	} else {
		echo "<p class='alert alert-danger' style='text-align:center'>Something Went Wrong</p>";
	}
}
?>