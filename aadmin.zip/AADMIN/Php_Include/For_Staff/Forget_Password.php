<?php
if(isset($_POST['eid'])){
	require ("../dbcon.php");
	$eid=$_POST['eid'];
	$econ = $_POST[ 'econ' ];
	//$dob1 = strtotime( "$dob" );
	//$dob2 = date( 'Y-m-d', $dob1 );
	$sql="select * from faculty where fac_contact='$econ' and fac_email='$eid'";
	$result=mysqli_query($con,$sql);
	$numrows=mysqli_num_rows($result);
	if($numrows==true){
			$string = "";
			$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			for($i=0;$i<10;$i++)
			$string.=substr($chars,rand(0,strlen($chars)),1);
			$sql="UPDATE faculty set Fac_Password='$string' where fac_contact='$econ' and fac_email='$eid'";
			if(mysqli_query($con,$sql)){
				$sql="select * from faculty where fac_contact='$econ' and fac_email='$eid'";
				$result=mysqli_query($con,$sql);
				$row=mysqli_fetch_array($result);
				$email=$row['Fac_Email'];
				$subject="Password For Login To Surya World Systems";
				$headers="Psajad17@gmail.com";
				if(mail($email,$subject,"Your New Password Is:-  ".$string."\nPlease Change It By Logging To Your Portal\nThanks And Best Regards Surya World",$headers)){
					echo "<p class='alert alert-success' style='text-align:center'>Password Is Sent To Your Registered Email Id</p>";
				}
				else{
					echo "<p class='alert alert-warning' style='text-align:center'>Server Down Sorry For Inconvinance</p>";
				}
			}		
	}
	else{
			echo "<p class='alert alert-danger' style='text-align:center'>No Records Found..........?</p>";
		}
}

?>