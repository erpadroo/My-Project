<?php
if ( isset( $_POST[ 'attendence' ] ) ) {
	for ( $i = 0; $i <= $_POST[ 'rows' ]; $i++ ) {
		@$rollno = $_POST[ 'rollno' . $i ];
		@$sub_name = $_POST[ 'courname' . $i ];
		@$stud_name = $_POST[ 'stud_name' . $i ];
		@$classes = $_POST[ 'class' . $i ];
		@$Sem_Id = $_POST[ 'sem_id' . $i ];
		$sql = "select * from attendence where rollno = '$rollno' and subject_name='$sub_name'";
		$result = mysqli_query( $con, $sql );
		$numrows = mysqli_num_rows( $result );
		if ( $numrows == 0 ) {
			$date = date( "Y-m-d" );
			$sql = "select *,Max(Total_Classes) from attendence where rollno = '$rollno' and subject_name='$sub_name'";
			$result = mysqli_query( $con, $sql );
			$numrows = mysqli_fetch_array( $result );
			$t_classes = $numrows[ 'Max(Total_Classes)' ] + 1;
			$at_classes = $numrows[ 'Classes_Attended' ] + $classes;
			$sql = "insert into attendence(Rollno,Name,Subject_Name,Classes_Attended,Total_Classes,Sem_Id,Start_Date,End_Date) values ('$rollno','$stud_name','$sub_name','$at_classes','$t_classes','$Sem_Id','$date','$date')";
			if ( mysqli_query( $con, $sql ) ) {
				$attendenceint = true;
			}
		} else {
			$date = date( "Y-m-d" );
			$sql = "select *,Max(Total_Classes)from attendence where rollno = '$rollno' and subject_name='$sub_name'";
			$result = mysqli_query( $con, $sql );
			$numrows = mysqli_fetch_array( $result );
			$t_classes = $numrows[ 'Max(Total_Classes)' ] + 1;
			$s_date = $numrows[ 'Start_Date' ];
			$at_classes = $numrows[ 'Classes_Attended' ] + $classes;
			$sql = "update attendence set Rollno = '$rollno',Name='$stud_name',Subject_Name='$sub_name',Classes_Attended='$at_classes',Total_Classes='$t_classes',Sem_Id='$Sem_Id',Start_Date='$s_date',End_Date='$date' where rollno = '$rollno' and subject_name='$sub_name'";
			if ( mysqli_query( $con, $sql ) ) {
				$attendenceupd = true;
			}
		}
	}
}
?>