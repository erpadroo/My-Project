<?php
if ( isset( $_POST[ 'insert_marks' ] ) ) {
	for ( $i = 0; $i < $_POST[ 'rows' ]; $i++ ) {
		@$roll_no = $_POST[ 'rollno' . $i ];
		@$sessional = $_POST[ 'sessional_marks' . $i ];
		@$sub_name = $_POST[ 'sub_name' . $i ];
		@$practical = $_POST[ 'practrical_marks' . $i ];
		@$theory = $_POST[ 'theory_marks' . $i ];
		@$sem_id = $_POST[ 'sem_id' . $i ];
		@$total_marks = $_POST[ 'total_marks'];
		echo $total_marks;
		$sql = "select * from exam_performance where Student_Rollno='$roll_no' and subject_name='$sub_name'";
		$result = mysqli_query( $con, $sql );
		$numrows = mysqli_num_rows( $result );
		if ( $numrows == 0 ) {
			$sql = "insert into exam_performance (Subject_Name,Sessional_Marks,Practical_Marks,Theory_Marks,Student_Rollno,Sem_id,Subject_Total_Marks,Hod_Review) VALUES ('$sub_name','$sessional','$practical','$theory','$roll_no','$sem_id','$total_marks',false)";
			if ( mysqli_query( $con, $sql ) ) {
				$marksint = true;
			} else {
				die( mysqli_error( $con ) );
			}
		} else {
			$sql = "select * from exam_performance where Student_Rollno='$roll_no' and subject_name='$sub_name'";
			$result = mysqli_query( $con, $sql );
			$numrows2 = mysqli_fetch_array( $result );
			if ( $numrows2[ 'Sessional_Marks' ] < $sessional and $numrows2[ 'Sessional_Marks' ] < $practical and $numrows2[ 'Sessional_Marks' ] < $theory ) {
				$sql = "update exam_performance  set Sessional_Marks='$sessional',Practical_Marks='$practical',Theory_Marks='$theory' where Student_Rollno='$roll_no' and Subject_Name='$sub_name' ";
				if ( mysqli_query( $con, $sql ) ) {
					$marksupd = true;
				} else {
					$error = true;
				}
			}
		}
	}
}
?>