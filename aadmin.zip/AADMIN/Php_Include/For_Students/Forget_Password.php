<?php
if(isset($_POST['rollno'])){
	require ("../dbcon.php");
	$rollno=$_POST['rollno'];
	$dob = $_POST[ 'dob' ];
	$dob1 = strtotime( "$dob" );
	$dob2 = date( 'Y-m-d', $dob1 );
	$sql="select * from students where rollno='$rollno' and Date_Of_Birth='$dob2'";
	$result=mysqli_query($con,$sql);
	$numrows=mysqli_num_rows($result);
	if($numrows==true){
			$string = "";
			$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			for($i=0;$i<10;$i++)
			$string.=substr($chars,rand(0,strlen($chars)),1);
			$sql="UPDATE students set Password='$string' where rollno='$rollno' and Date_Of_Birth='$dob2'";
			if(mysqli_query($con,$sql)){
				$sql="select * from students where rollno='$rollno' and Date_Of_Birth='$dob2'";
				$result=mysqli_query($con,$sql);
				$row=mysqli_fetch_array($result);
				$email=$row['Email'];
				$subject="Password For Login To Surya World Systems";
				$headers="Psajad17@gmail.com";
				if(mail($email,$subject,"Your Password Is:-  ".$string,"Thamks For Using Our System")){
					echo "<p class='label label-success' style='text-align:center'>Password Is Sent To Your Registered Email Id</p>";
				}
				else{
					echo "<p class='label label-swarning' style='text-align:center'>Server Down Sorry For Inconvinance</p>";
				}
			}		
	}
	else{
			echo "<p class='label label-warning'>No Records Found..........?</p>";
		}
}

?>