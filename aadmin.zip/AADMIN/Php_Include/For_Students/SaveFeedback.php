<?php
require( "../dbcon.php" );
if ( isset( $_POST[ 'one' ] ) ) {
	@$one = $_POST[ 'one' ];
	@$two = $_POST[ 'two' ];
	@$three = $_POST[ 'three' ];
	@$four = $_POST[ 'four' ];
	@$five = $_POST[ 'five' ];
	@$six = $_POST[ 'six' ];
	@$seven = $_POST[ 'seven' ];
	$course_id = $_POST[ 'course' ];
	$rollno = $_POST[ 'rollno' ];
	$sqlc = "Select * from courses where cour_id='$course_id'";
	$resultc = mysqli_query( $con, $sqlc );
	$rowc = mysqli_fetch_array( $resultc );
	$cour = $rowc[ 'Cour_Name' ];
	if ( $course_id == ''
		or $one == ''
		or $two == ''
		or $three == ''
		or $four == ''
		or $five == ''
		or $six == ''
		or $seven == '' ) {
		echo "<p class='alert alert-danger' style='text-align:center'>Please Answer All Questions</p>";
	} else {
		//$dept = $_POST['dept'];
		$commit = $_POST[ 'commit' ];
		$date = date( "Y-m-d" );
		$newDate = strtotime( $date );
		$Month = date( 'm', $newDate );
		$sql = "select * from date where for_month = '$Month'";
		//$sql = "select * from date where date_format( date( date_date ) , '%m' ) = '$Month'";
		$result = mysqli_query( $con, $sql );
		$numrows = mysqli_num_rows( $result );
		if ( $numrows == 0 ) {
			$sql1 = "insert into date (for_month) values('$Month')";
			mysqli_query( $con, $sql1 );
		}
		$sql = "select * from date where for_month = '$Month'";
		$result = mysqli_query( $con, $sql );
		$row = mysqli_fetch_array( $result );
		$dateid = $row[ 'date_id' ];
		$sql = "select * from feedback where feed_enroll_id = '$rollno' and feed_date_id = '$dateid' and feed_course_id='$course_id'";
		$result = mysqli_query( $con, $sql );
		$numrows = mysqli_num_rows( $result );
		if ( $numrows == 0 ) {
			$count = count( $course_id );
			$sql = "insert into feedback (feed_enroll_id,feed_course_id,feed_data,feed_date_id,one,two,three,four,five,six,seven,comment) values ('$rollno','$course_id','$count','$dateid','$one','$two','$three','$four','$five','$six','$seven','$commit')";
			mysqli_query( $con, $sql );
			echo "<p class='alert alert-success' style='text-align:center'>FeedBack Given Successfully For <b>" . $cour . "</b></p>";
		} else {
			$count = count( $course_id );
			$sql = "update feedback set feed_data = '$count',one='$one',two='$two',three='$three',four='$four',five='$five',six='$six',seven='$seven',comment='$commit' where feed_course_id = '$course_id' and feed_enroll_id = '$rollno'";
			mysqli_query( $con, $sql );
			echo "<p class='alert alert-success' style='text-align:center'>FeedBack Updated Successfully For <b>" . $cour . "</b></p>";
		}
	}
}
?>