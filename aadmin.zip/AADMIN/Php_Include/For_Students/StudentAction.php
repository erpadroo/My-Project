<?php
// Check if image file is a actual image or fake image
if ( isset( $_POST[ "insert" ] ) ) {

	$id = $_POST[ 'id' ];
	$sql = "select photo from students where rollno='$id'";
	$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
	$row = mysqli_fetch_array( $result );
	if ( $row[ 'photo' ] == '' ) {
		$target_dir = "Uploads/";
		$target_file = $target_dir . basename( $_FILES[ "image" ][ "name" ] );
		$uploadOk = 1;
		$imageFileType = pathinfo( $target_file, PATHINFO_EXTENSION );
		$check = getimagesize( $_FILES[ "image" ][ "tmp_name" ] );
		// Check if file already exists
		if ( file_exists( $target_file ) ) {
			?>
			<script>
				alert( "Sorry, file already exists." );
			</script>
			<?php
			$uploadOk = 0;
		}
		// if everything is ok, try to upload file
		else {
			if ( move_uploaded_file( $_FILES[ "image" ][ "tmp_name" ], $target_file ) ) {
				$target_path = basename( $_FILES[ "image" ][ "name" ] ); // used to store the filename in a variable
				//storing the data in your database
				$query = "update students set photo='$target_path' where rollno='$id'";
				if ( mysqli_query( $con, $query ) ) {
					?>
					<script>
						alert( "Your Profile has been Updated, page will refresh in 3 seconds.... to take effects" );
					</script>
					<?php
					header( "Refresh:3; url=students.php", true, 303 );
				} else {
					echo "Not Done";
				}
			} else {
				?>
				<script>
					alert( "Sorry, there was an error uploading your file." );
				</script>
				<?php
			}
		}
	} else {
		?>
		<script>
			alert( "You Have Already Set Your Profile." );
		</script>
		<?php

	}
}
?>