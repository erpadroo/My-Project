<div id="imageModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Image</h4>
			</div>
			<div class="modal-body">
				<form id="image_form" method="post" enctype="multipart/form-data">
					<p><label>Select Image</label>
						<input type="file" name="image" id="image"/>
					</p><br/>
					<input type="hidden" name="id" id="id" value="<?php echo $rollno;?>"/>
					<button type="submit" name="insert" id="insert" class="btn btn-info">Insert</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!-- ./wrapper -->
<script>
	$( document ).ready( function () {
		$( '#add' ).click( function () {
			$( '#imageModal' ).modal( 'show' );
			$( '#image_form' )[ 0 ].reset();
			$( '.modal-title' ).text( "Add Image" );
		} );
	} );
	$( '#insert' ).click( function () {
		var image = $( '#image' ).val();
		if ( image == '' ) {
			alert( "Please Select Image" );
			return false;
		} else if ( typeof ( $( "#image" )[ 0 ].files ) != "undefined" ) {
			var size = parseFloat( $( "#image" )[ 0 ].files[ 0 ].size / 1024 ).toFixed( 2 );
			if ( size <= 1000000 ) {
				return true;
			} else {
				alert( "Image Size Should Not Exceed 1MB" );
				$( '#image' ).val( '' );
				return false;
			}
		} else {
			var extension = $( '#image' ).val().split( '.' ).pop().toLowerCase();
			if ( jQuery.inArray( extension, [ 'gif', 'png', 'jpg', 'jpeg' ] ) == -1 ) {
				alert( "Invalid Image File" );
				$( '#image' ).val( '' );
				return false;
			}
		}
	} );
</script>