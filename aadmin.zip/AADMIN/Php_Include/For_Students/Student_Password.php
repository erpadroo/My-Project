<?php
if ( isset( $_POST[ 'set_password' ] ) ) {
	$rollno = $_POST[ 'search_text' ];
	@$password = $_POST[ 'student_password' ];
	if ( $password == ''
		or $rollno == '' ) {
		$errors = true;
	} else {
		$sql = "update students set password='$password',Status='1' where rollno='$rollno'";
		if ( mysqli_query( $con, $sql ) ) {
			$successs = true;
		} else {
			$errors = true;
		}
	}
}
?>