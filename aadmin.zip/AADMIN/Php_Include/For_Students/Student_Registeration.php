<?php
//fetch.php
include_once "../dbcon.php";
$output = '';
if ( isset( $_POST[ "query" ] ) ) {
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$query = " SELECT * FROM students WHERE Rollno LIKE '" . $search . "' and password='' limit 1";
	$result = mysqli_query( $con, $query );
	if ( mysqli_num_rows( $result ) > 0 ) {
		while ( $row = mysqli_fetch_array( $result ) ) {
			$output .= '<input type="password" name="student_password" placeholder="Password" required autocomplete="off">';
		}
		echo $output;
	} else {
		echo '<p class="alert alert-danger" style="text-align:center;font-weight:bolder;">Data Not Found or Already Registered</p>';
	}
}
?>