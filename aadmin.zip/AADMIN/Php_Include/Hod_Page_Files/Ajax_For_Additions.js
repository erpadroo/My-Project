$(document).ready(function () {
	$("#addcourse2").click(function () {
		var course_id = $("#course_id").val();
		var course_name = $("#course_name").val();
		var dept_id = $('#dept_id').val();
		var sem_id = $('#sem_id').val();
		var faculty_id = $('#faculty_id').val();
		if (course_id == '') {
			$("#course_id").focus();
		} else if (course_name == '') {
			$("#course_name").focus();
		} else if (sem_id == '1') {
			$("#sem_id").focus();
		} else if (faculty_id == '1') {
			$('#faculty_id').focus();
		} else {
			$.ajax({
				type: "post",
				url: "../Php_Include/Additions.php",
				data: {
					course_id: course_id,
					course_name: course_name,
					dept_id: dept_id,
					sem_id: sem_id,
					faculty_id: faculty_id
				},
				success: function (data) {
					$("#info").html(data);
					document.getElementById("course_id").value = '';
					document.getElementById("course_name").value = '';
					document.getElementById("sem_id").value = '1';
					document.getElementById("faculty_id").value = '1';
				}
			});
		}
	});

	$("#addstaff").click(function () {
		var f_id = $("#f_id").val();
		var ff_name = $("#ff_name").val();
		var f_phone = $('#f_phone').val();
		var f_email = $('#f_email').val();
		var f_address = $('#f_address').val();
		var phonef = f_phone.replace(/[^0-9]/g, '');
		var atpos = f_email.indexOf("@");
		var dotpos = f_email.lastIndexOf(".");
		if (f_id == '') {
			$("#f_id").focus();
		} else if (ff_name == '') {
			$("#ff_name").focus();
		} else if (f_address == '') {
			$('#f_address').focus();
		} else if (phonef.length != 10) {
			alert('Phone Number Must Be 10 Digits.');
			$('#f_phone').val('');
			$('#f_phone').focus();
		} else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= f_email.length) {
			alert("Not A Valid E-mail Address");
			$('#f_email').val('');
			$('#f_email').focus();
		} else {
			$.ajax({
				type: "post",
				url: "../Php_Include/Additions.php",
				data: {
					f_id: f_id,
					ff_name: ff_name,
					f_phone: f_phone,
					f_email: f_email,
					f_address: f_address
				},
				success: function (data) {
					$("#info2").html(data);
					document.getElementById("f_id").value = '';
					document.getElementById("ff_name").value = '';
					document.getElementById("f_phone").value = '';
					document.getElementById("f_address").value = '';
					document.getElementById("f_email").value = '';
				}
			});
		}
	});

	$("#students").click(function () {
		var uni_roll = $("#uni_roll").val();
		var student_name = $("#student_name").val();
		var dept_id = $('#dept_id').val();
		var sem_idd = $('#sem_idd').val();
		var contact = $('#contact').val();
		var dob = $('#dob').val();
		var f_name = $('#f_name').val();
		var f_contact = $('#f_contact').val();
		var m_name = $('#m_name').val();
		var s_email = $('#s_email').val();
		var p_address = $('#p_address').val();
		var c_address = $('#c_address').val();
		var phone = contact.replace(/[^0-9]/g, '');
		var phonea = f_contact.replace(/[^0-9]/g, '');
		var atposs = s_email.indexOf("@");
		var dotposs = s_email.lastIndexOf(".");
		if (uni_roll == '') {
			$("#uni_roll").focus();
		} else if (student_name == '') {
			$("#student_name").focus();
		} else if (phone.length != 10) {
			alert('Phone Number Must Be 10 Digits.');
			$('#contact').val('');
			$('#contact').focus();
		} else if (dob == '') {
			$("#dob").focus();
		} else if (f_name == '') {
			$('#f_name').focus();
		} else if (phonea.length != 10) {
			alert('Phone Number Must Be 10 Digits.');
			$('#f_contact').val('');
			$('#f_contact').focus();
		} else if (m_name == '') {
			$('#m_name').focus();
		} else if (atposs < 1 || dotposs < atposs + 2 || dotposs + 2 >= s_email.length) {
			alert("Not A Valid E-mail Address");
			$('#s_email').val('');
			$('#s_email').focus();
		} else if (p_address == '') {
			$('#p_address').focus();
		} else if (c_address == '') {
			$('#c_address').focus();
		} else if (sem_idd == '1') {
			$("#sem_idd").focus();
		} else {
			$.ajax({
				type: "post",
				url: "../Php_Include/Additions.php",
				data: {
					uni_roll: uni_roll,
					student_name: student_name,
					dept_id: dept_id,
					sem_idd: sem_idd,
					contact: contact,
					dob: dob,
					f_name: f_name,
					f_contact: f_contact,
					m_name: m_name,
					s_email: s_email,
					p_address: p_address,
					c_address: c_address
				},
				success: function (data) {
					$("#info3").html(data);
					document.getElementById("uni_roll").value = '';
					document.getElementById("student_name").value = '';
					document.getElementById("sem_idd").value = '1';
					document.getElementById("contact").value = '';
					document.getElementById("dob").value = '';
					document.getElementById("f_name").value = '';
					document.getElementById("f_contact").value = '';
					document.getElementById("m_name").value = '';
					document.getElementById("s_email").value = '';
					document.getElementById("p_address").value = '';
					document.getElementById("c_address").value = '';
				}
			});
		}
	});
});
