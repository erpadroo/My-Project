<?php
//fetch.php
include_once "../dbcon.php";
$output = '';
if ( isset( $_POST[ "query" ] ) ) {
	session_start();
	$username = $_SESSION[ 'email' ];
	$sql5 = "select * from faculty where fac_email='$username'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row4 = mysqli_fetch_array( $result5 );
	$sql5 = "select * from departments where dept_hod='" . $row4[ 'Fac_Id' ] . "'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row5 = mysqli_fetch_array( $result5 );
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$query = "  SELECT * FROM students WHERE Rollno = '" . $search . "' and dept_id='" . $row5[ 'Dept_Id' ] . "'";
	$result = mysqli_query( $con, $query );
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$date = strtotime( $search );
	$date = date( 'Y-m-d', $date );
	$query = "SELECT * FROM students WHERE Rollno LIKE '" .$search. "%'  OR name LIKE '" . $search . "%' 
  OR fathers_name LIKE '" . $search . "%' 
  OR mothers_name LIKE '" . $search . "%' OR date_of_birth = '" . $date . "' and dept_id='" . $row5[ 'Dept_Id' ] . "'";
	$result = mysqli_query( $con, $query );
	if ( mysqli_num_rows( $result ) > 0 ) {
		$output .= '
  <div class="">
   <table class="table table-bordered table-striped">
    <tr>
     <th class="center">ROLL NUMBER</th>
     <th class="center">NAME</th>
     <th class="center">S/O-D/O</th>
     <th class="center">CONTACT NUMBER</th>
     <th class="center">PERFORMANCE</th>
    </tr>
 ';
		while ( $row = mysqli_fetch_array( $result ) ) {
			$output .= '
   <tr class="table-active">
    <td class="center">' . $row[ "Rollno" ] . '</td>
    <td class="center">' . $row[ "Name" ] . '</td>
    <td class="center">' . $row[ "Fathers_Name" ] . '</td>
    <td class="center">' . $row[ "Contact" ] . '</td>
    <td class="center"><a class="btn btn-success btn-sm" href="Performance.php?id=' . $row[ "Rollno" ] . '">Check' . '</a></td>
   </tr>
  ';
		}
		echo $output;
	} else {
		echo '<p class="alert alert-danger" style="text-align:center;">Data Not Found</p>';
	}
}

?>