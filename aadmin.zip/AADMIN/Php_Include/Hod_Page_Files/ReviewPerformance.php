<?php
if ( isset( $_POST[ 'update_marks' ] ) ) {
	for ( $i = 0; $i < $_POST[ 'rows' ]; $i++ ) {
		@$roll_no = $_POST[ 'rollno' . $i ];
		@$sessional = $_POST[ 'sessional_marks' . $i ];
		@$sub_name = $_POST[ 'sub_name' . $i ];
		@$practical = $_POST[ 'practrical_marks' . $i ];
		@$theory = $_POST[ 'theory_marks' . $i ];
		$sql = "select * from exam_performance where Student_Rollno='$roll_no' and subject_name='$sub_name'";
		$result = mysqli_query( $con, $sql );
		$numrows = mysqli_num_rows( $result );
		if ( $numrows == 1 ) {
			$sql = "update exam_performance  set Sessional_Marks='$sessional',Practical_Marks='$practical',Theory_Marks='$theory',Hod_Review=true where Student_Rollno='$roll_no' and Subject_Name='$sub_name' ";
				if ( mysqli_query( $con, $sql )or die(mysqli_error($con)) ) {
					$marksupd = true;
				} else {
					$error = true;
				}
		}
	}
}
?>