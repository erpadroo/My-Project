$(document).ready(function () {
	load_data();

	function load_data(query) {
		$.ajax({
			url: "../Php_Include/Hod_Page_Files/Performance_Student_Search.php",
			method: "POST",
			data: {
				query: query
			},
			success: function (data) {
				$('#result').html(data);
			}
		});
	}
	$('#search_text').keyup(function () {
		var search = $(this).val();
		if (search != '') {
			load_data(search);
		} else {
			load_data();
		}
	});
});
$(document).ready(function () {
	load_data();

	function load_data(query) {
		$.ajax({
			url: "../Php_Include/Hod_Page_Files/Update_Student_Search.php",
			method: "POST",
			data: {
				query: query
			},
			success: function (data) {
				$('#searched').html(data);
			}
		});
	}
	$('#uni_roll2').keyup(function () {
		var search = $(this).val();
		if (search != '') {
			load_data(search);
		} else {
			load_data();
		}
	});
});
$(document).ready(function () {
	load_data();

	function load_data(query) {
		$.ajax({
			url: "../Php_Include/Hod_Page_Files/Update_Faculty_Search.php",
			method: "POST",
			data: {
				query: query
			},
			success: function (data) {
				$('#searchedfaculty').html(data);
			}
		});
	}
	$('#f_idd').keyup(function () {
		var search = $(this).val();
		if (search != '') {
			load_data(search);
		} else {
			load_data();
		}
	});
});
$(document).ready(function () {
	load_data();

	function load_data(query) {
		$.ajax({
			url: "../Php_Include/Hod_Page_Files/Update_Course_Search.php",
			method: "POST",
			data: {
				query: query
			},
			success: function (data) {
				$('#searchedcourse').html(data);
			}
		});
	}
	$('#course_id2').keyup(function () {
		var search = $(this).val();
		if (search != '') {
			load_data(search);
		} else {
			load_data();
		}
	});
});
$(function () {
	$('#example1').DataTable()
	$('#example2').DataTable({
		'paging': true,
		'lengthChange': false,
		'searching': false,
		'ordering': true,
		'info': true,
		'autoWidth': false
	})
});
$(document).ready(function () {
	$("#changepassword").click(function () {
		var password = $("#password").val();
		var roll = $("#roll").val();
		$.ajax({
			type: "post",
			url: "../Php_Include/Hod_Page_Files/Change_Password.php",
			data: {
				password: password,
				roll: roll
			},
			success: function (data) {
				$("#fun").html(data);
				document.getElementById("password").value = '';
				window.location.href = document.URL;
			}
		});
	});
});
