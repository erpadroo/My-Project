<?php
if ( isset( $_POST[ 'send_student' ] ) ) {
	$data = array(
		'username' => urlencode( 'padroosajad' ),
		'password' => urlencode( '28431' ),
		'sender' => @$_POST[ 'sender' ],
		'message' => urlencode( $_POST[ 'text' ] ),
		'numbers' => @$_POST[ 'to' ]
	);
	// Send the POST request with cURL
	$port = 80;
	$ch = curl_init( 'http://subsms.obligr.com/api/pushsms.php?username=".$username."&password=".$password."&sender=".$sender."&message=".$message."&numbers=".$numbers."&unicode=false&flash=false' );
	curl_setopt( $ch, CURLOPT_POST, true );
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
	curl_setopt( $ch, CURLOPT_PORT, $port );
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	// Allowing cUrl funtions 20 second to execute
	curl_setopt( $ch, CURLOPT_TIMEOUT, 20 );
	// Waiting 20 seconds while trying to connect
	curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 20 );
	$resultr = curl_exec( $ch ); //This is the result from Gateway
	if ( curl_exec( $ch ) === false ) {
		$error = true;
	} else {
		$success = true;
		//print_r($data);
	}
	curl_close( $ch );
	//var_dump($result);
	//print_r($result);
}
?>
<?php
if ( isset( $_POST[ 'send_parent' ] ) ) {
	$data = array(
		'username' => urlencode( 'padroosajad' ),
		'password' => urlencode( '28431' ),
		'sender' => $_POST[ 'sender' ],
		'message' => urlencode( $_POST[ 'text' ] ),
		'numbers' => $_POST[ 'to' ]
	);
	// Send the POST request with cURL
	$port = 80;
	$ch = curl_init( 'http://subsms.obligr.com/api/pushsms.php?username=".$username."&password=".$password."&sender=".$sender."&message=".$message."&numbers=".$numbers."&unicode=false&flash=false' );
	curl_setopt( $ch, CURLOPT_POST, true );
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
	curl_setopt( $ch, CURLOPT_PORT, $port );
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	// Allowing cUrl funtions 20 second to execute
	curl_setopt( $ch, CURLOPT_TIMEOUT, 20 );
	// Waiting 20 seconds while trying to connect
	curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 20 );
	$resultr = curl_exec( $ch ); //This is the result from Gateway
	if ( curl_exec( $ch ) === false ) {
		$error1 = true;
	} else {
		$success1 = true;
		//print_r($data);
	}
	curl_close( $ch );
	//var_dump($result);
	//print_r($result);
}
?>