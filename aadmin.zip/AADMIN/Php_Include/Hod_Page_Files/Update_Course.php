<?php
include "../dbcon.php";
if ( isset( $_POST[ 'course_id' ] ) ) {
	$c_id = $_POST[ 'course_id' ];
	$c_name = $_POST[ 'course_name' ];
	$c_dept = $_POST[ 'course_department' ];
	$c_sem = $_POST[ 'course_semester' ];
	$c_fac = $_POST[ 'course_faculty' ];
	$sql = "
							update courses set cour_name='$c_name',cour_dept='$c_dept',
							cour_faculty='$c_fac',cour_sem='$c_sem' where Cour_Id='$c_id'";
	if ( mysqli_query( $con, $sql ) ) {
		echo "Faculty Updated Successfully";
	} else {
		die( mysqli_error( $con ) );
		//echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
	}
}
?>