<?php
//fetch.php
include_once "../dbcon.php";
$output = '';
if ( isset( $_POST[ "query" ] ) ) {
	session_start();
	$username = $_SESSION[ 'email' ];
	$sql5 = "select * from faculty where fac_email='$username'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row4 = mysqli_fetch_array( $result5 );
	$sql5 = "select * from departments where dept_hod='" . $row4[ 'Fac_Id' ] . "'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row5 = mysqli_fetch_array( $result5 );
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$query = "  SELECT * FROM Courses WHERE Cour_Id = '" . $search . "' and cour_dept='" . $row5[ 'Dept_Id' ] . "'";
	$result = mysqli_query( $con, $query );
	if ( mysqli_num_rows( $result ) > 0 ) {
		$output .= '';
		while ( $row = mysqli_fetch_array( $result ) ) {
			$output .= '   
                <form id="fffff" method="post" style="text-align:center;">
					<div class="form-group input-group" >
						<span class="input-group-addon"> Course Id </span>  
						<input type="text" name="course_id" id="course_id" class="form-control" style="height:35px;" value="' . $row[ 'Cour_Id' ] . '" readonly />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Course Name </span>  
						<input type="text" name="course_name" id="course_name" class="form-control" style="height:35px;"  value="' . $row[ 'Cour_Name' ] . '" required />
					</div>					
						<div class="form-group input-group">
							<span class="input-group-addon"> Course Department </span>
							<select class="form-control"  name="course_department"  id="course_department"  style="height:35px;" readonly>';
			$sql5 = "select * from departments where dept_id='" . $row[ 'Cour_Dept' ] . "'";
			$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
			while ( $row5 = mysqli_fetch_array( $result5 ) ) {
				$output .= '<option value="' . $row5[ 'Dept_Id' ] . '">' . $row5[ 'Dept_Name' ] . '</option>';
			}
			$output .= '</select>
						</div>					
						<div class="form-group input-group">
							<span class="input-group-addon"> Course Semester </span>
							<select class="form-control"  name="course_semester"  id="course_semester"  style="height:35px;">
							<option select="selected" value="' . $row[ 'Cour_Sem' ] . '">' . $row[ 'Cour_Sem' ] . '</option>';
			$sql5 = "select * from Semesters where dept_id='" . $row[ 'Cour_Dept' ] . "'";
			$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
			while ( $row5 = mysqli_fetch_array( $result5 ) ) {
				$output .= '<option value="' . $row5[ 'Sem_Id' ] . '">' . $row5[ 'Sem_Name' ] . '</option>';
			}
			$output .= '</select>
						</div>
						<div class="form-group input-group">
							<span class="input-group-addon"> Course Semester </span>
							<select class="form-control"  name="course_faculty"  id="course_faculty"  style="height:35px;">
							<option select="selected" value="' . $row[ 'Cour_Faculty' ] . '">' . $row[ 'Cour_Faculty' ] . '</option>';
			$sql5 = "select * from Faculty";
			$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
			while ( $row5 = mysqli_fetch_array( $result5 ) ) {
				$output .= '<option value="' . $row5[ 'Fac_Id' ] . '">' . $row5[ 'Fac_Name' ] . '</option>';
			}
			$output .= '</select>
						</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" name="updatecourse" id="updatecourse" class="btn btn-warning btn-lg " >
							<i class="fa fa-upload"></i> Update Course
						</button>
					</div>
				</form>';
		}
		?>
		<script>
			$( "#updatecourse" ).click( function () {
				var course_id = $( "#course_id" ).val();
				var course_name = $( "#course_name" ).val();
				var course_department = $( '#course_department' ).val();
				var course_semester = $( '#course_semester' ).val();
				var course_faculty = $( '#course_faculty' ).val();;
				if ( course_id == '' ) {
					$( "#course_id" ).focus();
				} else if ( course_name == '' ) {
					$( "#course_name" ).focus();
				} else if ( course_department == '' ) {
					$( '#course_department' ).focus();
				} else if ( course_semester == '' ) {
					$( '#course_semester' ).focus();
				} else if ( course_faculty == '' ) {
					$( '#course_faculty' ).focus();
				} else {
					$.ajax( {
						type: "post",
						url: "../Php_Include/Hod_Page_Files/Update_Course.php",
						data: {
							course_id: course_id,
							course_name: course_name,
							course_department: course_department,
							course_semester: course_semester,
							course_faculty: course_faculty
						},
						success: function ( data ) {
							alert( "Course Updated Successfully" );
							$( "#course_id2" ).val( '' );
							$( "#fffff" ).hide();
						}
					} );
				}
			} );
			$( document ).ready( function () {
				$( "#hidden" ).hide();
			} );
		</script>
		<?php
		echo '<p class="alert alert-info" style="text-align:center;">Below Are The Details Of Course You Want To Update</p>';
		echo $output;
	} else {
		echo '<p class="alert alert-danger" style="text-align:center;">Course Not Found Please Fill Below Form To Add Course</p>';
		?>
		<script>
			$( document ).ready( function () {
				$( "#hiden" ).show();
			} );
		</script>
		<?php
	}
}
?>