<?php
include "../dbcon.php";
if ( isset( $_POST[ 'ff_id' ] ) ) {
	$ff_id = $_POST[ 'ff_id' ];
	$ff_name = $_POST[ 'ff_name' ];
	$ff_contact = $_POST[ 'ff_contact' ];
	$ff_email = $_POST[ 'ff_email' ];
	$ff_address = $_POST[ 'ff_address' ];
	$sql = "
							update faculty set Fac_Name='$ff_name',Fac_Contact='$ff_contact',
							Fac_Email='$ff_email',Fac_Address='$ff_address' where Fac_Id='$ff_id'";
	if ( mysqli_query( $con, $sql ) ) {
		echo "Faculty Updated Successfully";
	} else {
		die( mysqli_error( $con ) );
		//echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
	}
}
?>