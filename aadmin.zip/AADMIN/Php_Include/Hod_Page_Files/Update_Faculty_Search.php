<?php
//fetch.php
include_once "../dbcon.php";
$output = '';
if ( isset( $_POST[ "query" ] ) ) {
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$query = "  SELECT * FROM faculty WHERE Fac_Id = '" . $search . "' or Fac_Name='" . $search . "'";
	$result = mysqli_query( $con, $query );
	if ( mysqli_num_rows( $result ) > 0 ) {
		$output .= '';
		while ( $row = mysqli_fetch_array( $result ) ) {
			$output .= '   
                <form id="ffff" method="post" style="text-align:center;">
					<div id="info4"></div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Faculty Id </span>  
						<input type="text" name="ff_id" id="ff_id" class="form-control" style="height:35px;" value="' . $row[ 'Fac_Id' ] . '" readonly />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Faculty Name </span>  
						<input type="text" name="ff_name" id="ff_name" class="form-control" style="height:35px;"  value="' . $row[ 'Fac_Name' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Faculty Contact Number </span>  
						<input type="text" name="ff_contact" id="ff_contact" class="form-control" style="height:35px;"  value="' . $row[ 'Fac_Contact' ] . '"  />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Faculty Email </span>  
						<input type="email" name="ff_email" id="ff_email" class="form-control" style="height:35px;" value="' . $row[ 'Fac_Email' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Faculty Permenent Address </span>  
						<input type="text" name="ff_address" id="ff_address" class="form-control" style="height:35px;" value="' . $row[ 'Fac_Address' ] . '" required />
					</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" name="updatefaculty" id="updatefaculty" class="btn btn-warning btn-lg " >
							<i class="fa fa-upload"></i> Update Faculty
						</button>
					</div>
				</form>';
		}
		?>
		<script>
			$( "#updatefaculty" ).click( function () {
				var ff_id = $( "#ff_id" ).val();
				var ff_name = $( "#ff_name" ).val();
				var ff_contact = $( '#ff_contact' ).val();
				var ff_email = $( '#ff_email' ).val();
				var ff_address = $( '#ff_address' ).val();
				var phone = ff_contact.replace( /[^0-9]/g, '' );
				var atposs = ff_email.indexOf( "@" );
				var dotposs = ff_email.lastIndexOf( "." );
				if ( ff_id == '' ) {
					$( "#ff_id" ).focus();
				} else if ( ff_name == '' ) {
					$( "#ff_name" ).focus();
				} else if ( phone.length != 10 ) {
					alert( 'Phone Number Must Be 10 Digits.' );
					$( '#ff_contact' ).val( '' );
					$( '#ff_contact' ).focus();
				} else if ( atposs < 1 || dotposs < atposs + 2 || dotposs + 2 >= s_email.length ) {
					alert( "Not A Valid E-mail Address" );
					$( '#ff_email' ).val( '' );
					$( '#ff_email' ).focus();
				} else if ( ff_address == '' ) {
					$( '#ff_address' ).focus();
				} else {
					$.ajax( {
						type: "post",
						url: "../Php_Include/Hod_Page_Files/Update_Faculty.php",
						data: {
							ff_id: ff_id,
							ff_name: ff_name,
							ff_contact: ff_contact,
							ff_email: ff_email,
							ff_address: ff_address
						},
						success: function ( data ) {
							alert( "Faculty Updated Successfully" );
							$( "#f_idd" ).val( '' );
							$( "#ffff" ).hide();
						}
					} );
				}
			} );
			$( document ).ready( function () {
				$( "#hiden" ).hide();
			} );
		</script>
		<?php
		echo '<p class="alert alert-info" style="text-align:center;">Below Are The Details Of Faculty Member You Want To Update</p>';
		echo $output;
	} else {
		echo '<p class="alert alert-danger" style="text-align:center;">Faculty Member Not Found Please Fill Below Form To Add Faculty</p>';
		?>
		<script>
			$( document ).ready( function () {
				$( "#hiden" ).show();
			} );
		</script>
		<?php
	}
}
?>