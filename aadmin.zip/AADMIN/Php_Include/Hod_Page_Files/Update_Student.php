<?php
include "../dbcon.php";
if ( isset( $_POST[ 'uni_roll' ] ) ) {
	$uni_roll = $_POST[ 'uni_roll' ];
	$student_name = $_POST[ 'student_name' ];
	$dept_id = $_POST[ 'dept_id' ];
	$sem_idd = $_POST[ 'sem_idd' ];
	$contact = $_POST[ 'contact' ];
	$dob = $_POST[ 'dob' ];
	$dob1 = strtotime( "$dob" );
	$dob2 = date( 'Y-m-d', $dob1 );
	$f_name = $_POST[ 'f_name' ];
	$f_contact = $_POST[ 'f_contact' ];
	$m_name = $_POST[ 'm_name' ];
	$s_email = $_POST[ 's_email' ];
	$p_address = $_POST[ 'p_address' ];
	$c_address = $_POST[ 'c_address' ];
	$sql = "
							update students set Name='$student_name',Semester_Id='$sem_idd',
							Contact='$contact',Date_Of_Birth='$dob2',Fathers_Name='$f_name',
							Fathers_Contact='$f_contact',Mothers_Name='$m_name',Email='$s_email',
							Perment_Address='$p_address',Corres_Address='$c_address',
							dept_id='$dept_id' where rollno='$uni_roll'";
	if ( mysqli_query( $con, $sql ) ) {
		echo "<p class='alert alert-info' style='text-align:center'>Student Updated Successfully</p>";
	} else {
		die( mysqli_error( $con ) );
		//echo"<p class='alert alert-danger' style='text-align:center'>Something Went Wrong While Inserting Data</p>";
	}
}
?>