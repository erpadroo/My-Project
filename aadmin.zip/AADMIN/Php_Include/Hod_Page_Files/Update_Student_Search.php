<?php
//fetch.php
include_once "../dbcon.php";
$output = '';
if ( isset( $_POST[ "query" ] ) ) {
	session_start();
	$username = $_SESSION[ 'email' ];
	$sql5 = "select * from faculty where fac_email='$username'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row4 = mysqli_fetch_array( $result5 );
	$sql5 = "select * from departments where dept_hod='" . $row4[ 'Fac_Id' ] . "'";
	$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
	$row5 = mysqli_fetch_array( $result5 );
	$search = mysqli_real_escape_string( $con, $_POST[ "query" ] );
	$query = "  SELECT * FROM students WHERE Rollno = '" . $search . "' and dept_id='" . $row5[ 'Dept_Id' ] . "'";
	$result = mysqli_query( $con, $query );
	if ( mysqli_num_rows( $result ) > 0 ) {
		$output .= '';
		while ( $row = mysqli_fetch_array( $result ) ) {
			$date = strtotime( $row[ 'Date_Of_Birth' ] );
			$date2 = date( 'd/m/Y', $date );
			$output .= '
                <form id="fffff" method="post" style="text-align:center;">
					<div class="form-group input-group" >
						<span class="input-group-addon"> Student University Roll Number </span>  
						<input type="text" name="uni_roll" id="uni_roll" class="form-control" style="height:35px;" value="' . $row[ 'Rollno' ] . '" readonly />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Student Name </span>  
						<input type="text" name="student_name" id="student_name" class="form-control" style="height:35px;"  value="' . $row[ 'Name' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Contact Number </span>  
						<input type="text" name="contact" id="contact" class="form-control" style="height:35px;"  value="' . $row[ 'Contact' ] . '"  />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Date Of Birth </span>  
						<input type="text" name="dob" id="dob" class="form-control" style="height:35px;"  value="' . $date2 . '"  required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Fathers Name </span>  
						<input type="text" name="f_name" id="f_name" class="form-control" style="height:35px;" value="' . $row[ 'Fathers_Name' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Fathers Contact No. </span>  
						<input type="text" name="f_contact" id="f_contact" class="form-control" style="height:35px;" value="' . $row[ 'Fathers_Contact' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Mothers Name </span>  
						<input type="text" name="m_name" id="m_name" class="form-control" style="height:35px;" value="' . $row[ 'Mothers_Name' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Student Email </span>  
						<input type="email" name="s_email" id="s_email" class="form-control" style="height:35px;" value="' . $row[ 'Email' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Permenent Address </span>  
						<input type="text" name="p_address" id="p_address" class="form-control" style="height:35px;" value="' . $row[ 'Perment_Address' ] . '" required />
					</div>
					<div class="form-group input-group" >
						<span class="input-group-addon"> Correspondance Address </span>  
						<input type="text" name="c_address" id="c_address" class="form-control" style="height:35px;" value="' . $row[ 'Corres_Address' ] . '" required />
					</div>
						<div class="form-group input-group">
							<span class="input-group-addon"> Student Branch </span>
							<select class="form-control"  name="dept_id"  id="dept_id"  style="height:35px;">';
			$sql5 = "select * from departments where dept_id='" . $row[ 'Dept_Id' ] . "'";
			$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
			while ( $row5 = mysqli_fetch_array( $result5 ) ) {
				$output .= '<option value="' . $row5[ 'Dept_Id' ] . '">' . $row5[ 'Dept_Name' ] . '</option>';
			}
			$output .= '</select>
						</div>						
						<div class="form-group input-group">
							<span class="input-group-addon"> Student Semester/Class </span>
							<select class="form-control"  name="sem_idd"  id="sem_idd"  style="height:35px;">
							<option select="selected" value="' . $row[ 'Semester_Id' ] . '">' . $row[ 'Semester_Id' ] . '</option>';
			$sql = "select * from departments where dept_id='" . $row[ 'Dept_Id' ] . "'";
			$result = mysqli_query( $con, $sql );
			$row2 = mysqli_fetch_array( $result );
			$sql5 = "select * from semesters where dept_id='" . $row2[ 'Dept_Id' ] . "'";
			$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
			while ( $row5 = mysqli_fetch_array( $result5 ) ) {
				$output .= '<option value="' . $row5[ 'Sem_Id' ] . '">' . $row5[ 'Sem_Name' ] . '</option>';
			}
			$output .= '</select>
						</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" name="updatestudent" id="updatestudents" class="btn btn-warning btn-lg " >
							<i class="fa fa-upload"></i> Update Student
						</button>
					</div>
				</form>';
		}
		?>
		<script>
			$( '#dob' ).datepicker( {
				autoclose: true
			} );
			$( "#updatestudents" ).click( function () {
				var uni_roll = $( "#uni_roll" ).val();
				var student_name = $( "#student_name" ).val();
				var dept_id = $( '#dept_id' ).val();
				var sem_idd = $( '#sem_idd' ).val();
				var contact = $( '#contact' ).val();
				var dob = $( '#dob' ).val();
				var f_name = $( '#f_name' ).val();
				var f_contact = $( '#f_contact' ).val();
				var m_name = $( '#m_name' ).val();
				var s_email = $( '#s_email' ).val();
				var p_address = $( '#p_address' ).val();
				var c_address = $( '#c_address' ).val();
				var phone = contact.replace( /[^0-9]/g, '' );
				var phonea = f_contact.replace( /[^0-9]/g, '' );
				var atposs = s_email.indexOf( "@" );
				var dotposs = s_email.lastIndexOf( "." );
				if ( uni_roll == '' ) {
					$( "#uni_roll" ).focus();
				} else if ( student_name == '' ) {
					$( "#student_name" ).focus();
				} else if ( phone.length != 10 ) {
					alert( 'Phone Number Must Be 10 Digits.' );
					$( '#contact' ).val( '' );
					$( '#contact' ).focus();
				} else if ( dob == '' ) {
					$( "#dob" ).focus();
				} else if ( f_name == '' ) {
					$( '#f_name' ).focus();
				} else if ( phonea.length != 10 ) {
					alert( 'Phone Number Must Be 10 Digits.' );
					$( '#f_contact' ).val( '' );
					$( '#f_contact' ).focus();
				} else if ( m_name == '' ) {
					$( '#m_name' ).focus();
				} else if ( atposs < 1 || dotposs < atposs + 2 || dotposs + 2 >= s_email.length ) {
					alert( "Not A Valid E-mail Address" );
					$( '#s_email' ).val( '' );
					$( '#s_email' ).focus();
				} else if ( p_address == '' ) {
					$( '#p_address' ).focus();
				} else if ( c_address == '' ) {
					$( '#c_address' ).focus();
				} else if ( sem_idd == '1' ) {
					$( "#sem_idd" ).focus();
				} else {
					$.ajax( {
						type: "post",
						url: "../Php_Include/Hod_Page_Files/Update_Student.php",
						data: {
							uni_roll: uni_roll,
							student_name: student_name,
							dept_id: dept_id,
							sem_idd: sem_idd,
							contact: contact,
							dob: dob,
							f_name: f_name,
							f_contact: f_contact,
							m_name: m_name,
							s_email: s_email,
							p_address: p_address,
							c_address: c_address
						},
						success: function ( data ) {
							alert( "Student Updated Successfully" );
							$( "#uni_roll2" ).val( '' );
							$( "#fffff" ).hide();
						}
					} );
				}
			} );
			$( document ).ready( function () {
				$( "#hide" ).hide();
			} );
		</script>
		<?php
		echo '<p class="alert alert-info" style="text-align:center;">Below Are The Details Of Student You Want To Update</p>';
		echo $output;
	} else {
		echo '<p class="alert alert-danger" style="text-align:center;">Student Not Found Please Fill Below Form To Add Student</p>';
		?>
		<script>
			$( document ).ready( function () {
				$( "#hide" ).show();
			} );
		</script>
		<?php
	}
}
?>