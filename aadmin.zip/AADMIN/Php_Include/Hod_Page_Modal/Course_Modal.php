    <!-- Modal Cources -->
<div class="modal modal-info fade" id="addcourse">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
			
				<h4 class="modal-title">Add Cources/Subjects</h4>
			</div>
			<div class="modal-body">
				<form name="search" role="form" method="POST" onkeypress="return event.keyCode != 13;" style="text-align:center;">
					<div class="form-group input-group">
						<span class="input-group-btn">
											<button class="btn btn-secondary" type="button"><i class="fa fa-search fa-lg"></i></button>
										</span>
					
						<input type="text" name="course_id2" id="course_id2" class="form-control" placeholder="Search Courses......................." autocomplete="off"/>
					</div>
				</form>
				<div id="searchedcourse"></div>
				<div id="info"></div>
				<form method="post" style="text-align:center;" id="hidden">
					<div class="form-group input-group">
						<span class="input-group-addon"> Course Id </span>
						<input type="text" name="course_id" id="course_id" class="form-control" style="height:35px;" placeholder="e.g BTCS601" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon">Course Name </span>
						<input type="text" name="course_name" id="course_name" class="form-control" style="height:35px;" placeholder="e.g Microprocessor" required/>
					</div>
					<?php
					$sql5 = "select * from departments where dept_hod = '$hod_id'";
					$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
					?>
					<div class="form-group input-group">
						<span class="input-group-addon">Cource Department </span>
						<select class="form-control" name="dept_id" id="dept_id" style="height:35px;">
							<?php
							while ( $row5 = mysqli_fetch_array( $result5 ) ) {
								echo '<option value="' . $row5[ 'Dept_Id' ] . '">' . $row5[ 'Dept_Name' ] . '</option>';
							}
							?>

						</select>
					</div>
					<?php
					$sql5 = "select * from semesters where dept_id='$dept_id'";
					$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
					?>
					<div class="form-group input-group">
						<span class="input-group-addon">Cource Semester </span>
						<select class="form-control" name="sem_id" id="sem_id" style="height:35px;">
							<option select="selected" value="1">Please Select One.................. </option>
							<?php

							while ( $row5 = mysqli_fetch_array( $result5 ) ) {
								echo '<option value="' . $row5[ 'Sem_Id' ] . '">' . $row5[ 'Sem_Name' ] . '</option>';
							}
							?>
						</select>
					</div>

					<?php
					$sql5 = "select * from faculty where fac_id is not null";
					$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
					?>
					<div class="form-group input-group">
						<span class="input-group-addon">Cource Tutor </span>
						<select class="form-control" name="faculty_id" id="faculty_id" style="height:35px;">
							<option select="selected" value="1">Please Select One.................. </option>
							<?php
							while ( $row5 = mysqli_fetch_array( $result5 ) ) {
								echo '<option value="' . $row5[ 'Fac_Id' ] . '">' . $row5[ 'Fac_Name' ] . '</option>';
							}
							?>
						</select>
					</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" id="addcourse2" name="addcourse2" class="btn btn-success btn-lg ">
							<i class="fa fa-upload"></i> Save Changes
						</button>
					
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
    <!-- /.modal -->