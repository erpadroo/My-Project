<!--Faculty Modal-->
<div class="modal modal-primary fade" id="addfaculty">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span></button>
			
				<h4 class="modal-title">Add Faculty Members</h4>
			</div>
			<div class="modal-body">
				<form name="search" role="form" method="POST" onkeypress="return event.keyCode != 13;" style="text-align:center;">
					<div class="form-group input-group">
						<span class="input-group-btn">
											<button class="btn btn-secondary" type="button"><i class="fa fa-search fa-lg"></i></button>
										</span>
					
						<input type="text" name="f_idd" id="f_idd" class="form-control" placeholder="Search Faculty......................." autocomplete="off"/>
					</div>
				</form>
				<div id="searchedfaculty"></div>
				<div id="info2"></div>
				<form method="post" id="hiden">
					<div class="form-group input-group">
						<span class="input-group-addon"> Faculty Id </span>
						<input type="text" name="f_id" id="f_id" class="form-control" style="height:35px;" placeholder="e.g ESE001" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Name </span>
						<input type="text" name="ff_name" id="ff_name" class="form-control" style="height:35px;" placeholder="e.g Joe Doe" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Address </span>
						<input type="text" name="f_address" id="f_address" class="form-control" style="height:35px;" placeholder="e.g Rajpura Punjab" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Phone </span>
						<input type="text" name="f_phone" id="f_phone" class="form-control" style="height:35px;" placeholder="e.g 9797123456" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Email </span>
						<input type="email" name="f_email" id="f_email" class="form-control" style="height:35px;" placeholder="e.g example@example.com" required/>
					</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" name="addfaculty" id="addstaff" class="btn btn-success btn-lg ">
										<i class="fa fa-upload"></i> Save Changes
									</button>
					
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /End Faculty Modal -->