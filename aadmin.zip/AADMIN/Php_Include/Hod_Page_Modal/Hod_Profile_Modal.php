<!-- Modal Profile -->
<div class="modal modal-warning fade" id="profile">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								  <span aria-hidden="true">&times;</span></button>
			
				<h4 class="modal-title">Your Profile</h4>
			</div>
			<div class="modal-body">
				<?php
				$sql0 = "select * from faculty where Fac_email='$username'";
				$result0 = mysqli_query( $con, $sql0 )or die( mysqli_error( $con ) );
				$row0 = mysqli_fetch_array( $result0 );
				$hod_id = $row0[ 'Fac_Id' ];
				$hod_name = $row0[ 'Fac_Name' ];
				$sql = "SELECT * FROM departments WHERE dept_hod = '$hod_id'";
				$result = mysqli_query( $con, $sql )or die( mysqli_error( $con ) );
				$row3 = mysqli_fetch_array( $result );
				$dept_id = $row3[ 'Dept_Id' ];
				?>
				<div class="form-group input-group" style="margin-left:40%">
					<img src="<?php echo $path.$row0['Img_Name'];?>" alt="Pic" style="width:100px; height:100px;border-radius:50px"/>
				</div>
				<div id="fun"></div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Employee Id </span>
					<input type="text" value="<?php echo $hod_id;?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Name </span>
					<input type="text" value="<?php echo $hod_name;?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Contact Number </span>
					<input type="text" value="<?php echo $row0['Fac_Contact'];?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Department </span>
					<input type="text" value="<?php echo $row3['Dept_Name'];?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Email </span>
					<input type="text" value="<?php echo $row0['Fac_Email'];?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<div class="form-group input-group">
					<span class="input-group-addon"> Address </span>
					<input type="text" value="<?php echo $row0['Fac_Address'];?>" class="form-control" style="height:35px;" readonly/>
				</div>
				<form method="post" action="">
					<div class="form-group input-group">
						<span class="input-group-addon"> Password</span>
						<input type="text" id="password" name="password" value="<?php echo $row3['Hod_Password'];?>" class="form-control" style="height:35px;width:73.5%" readonly/>
						<input type="hidden" id="roll" value="<?php echo $hod_id;?>" class="form-control" style="height:35px;"/>
						<a id="myButton" class="btn btn-info" style="height:35px;margin-right:1px">Edit</a><button type="button" name="changepassword" id="changepassword" class="btn btn-info" style="height:35px;">Change</a>
											<script type="text/javascript">
												 var abc=document.getElementById('password').readOnly;
												 if(abc==true){
												 document.getElementById('myButton').onclick = function() {
												 document.getElementById('password').removeAttribute('readonly');
												};
												}
												else if(abc==false){
												 document.getElementById('myButton').onclick = function() {
												 document.getElementById('password').setAttribute('readonly');
												};								
												}
											</script>
										</div>	
									</form>	
							</div>
							  <div class="modal-footer">
								<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
					</div>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->