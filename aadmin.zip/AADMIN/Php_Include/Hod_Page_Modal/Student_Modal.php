          <!-- student Modal -->
<div class="modal modal-success fade" id="addstudent">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
			
				<h4 class="modal-title">Primary Modal</h4>
			</div>
			<div class="modal-body">
				<form name="search" role="form" method="POST" onkeypress="return event.keyCode != 13;" style="text-align:center;">
					<div class="form-group input-group">
						<span class="input-group-btn">
									<button class="btn btn-secondary" type="button"><i class="fa fa-search fa-lg"></i></button>
								</span>
					
						<input type="text" name="uni_roll2" id="uni_roll2" class="form-control" placeholder="Search Student......................." autocomplete="off"/>
					</div>
				</form>
				<div id="searched"></div>
				<div id="info3"></div>
				<form action="index.php" method="post" style="text-align:center;" id="hide">
					<div class="form-group input-group">
						<span class="input-group-addon"> Student University Roll Number </span>
						<input type="text" name="uni_roll" id="uni_roll" class="form-control" style="height:35px;" placeholder="e.g 1544393" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Student Name </span>
						<input type="text" name="student_name" id="student_name" class="form-control" style="height:35px;" placeholder="e.g SAJAD AHMAD PADROO" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Contact Number </span>
						<input type="text" name="contact" id="contact" class="form-control" style="height:35px;" placeholder="e.g +917780858639"/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Date Of Birth </span>
						<input type="text" name="dob" id="dob" class="form-control" style="height:35px;" placeholder="10-03-1994" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Fathers Name </span>
						<input type="text" name="f_name" id="f_name" class="form-control" style="height:35px;" placeholder="e.g BASHIR AHMAD PADROO" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Fathers Contact No. </span>
						<input type="text" name="f_contact" id="f_contact" class="form-control" style="height:35px;" placeholder="e.g 8715963549" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Mothers Name </span>
						<input type="text" name="m_name" id="m_name" class="form-control" style="height:35px;" placeholder="e.g HANEEFA BEGUM" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Student Email </span>
						<input type="email" name="s_email" id="s_email" class="form-control" style="height:35px;" placeholder="e.g Psajad17@gmail.com" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Permenent Address </span>
						<input type="text" name="p_address" id="p_address" class="form-control" style="height:35px;" placeholder="e.g Tiken Batpora" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Correspondance Address </span>
						<input type="text" name="c_address" id="c_address" class="form-control" style="height:35px;" placeholder="e.g Rajpura Punjab" required/>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Student Branch </span>
						<select class="form-control" name="dept_id" id="dept_id" style="height:35px;">
							<?php
							$sql5 = "select * from departments where dept_hod = '$hod_id'";
							$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
							while ( $row5 = mysqli_fetch_array( $result5 ) ) {
								echo '<option value="' . $row5[ 'Dept_Id' ] . '">' . $row5[ 'Dept_Name' ] . '</option>';
							}
							?>
						</select>
					</div>
					<div class="form-group input-group">
						<span class="input-group-addon"> Student Semester/Class </span>
						<select class="form-control" name="sem_idd" id="sem_idd" style="height:35px;">
							<option select="selected" value="1">Please Select One.................. </option>
							<?php
							$sql5 = "select * from semesters where dept_id = '$dept_id'";
							$result5 = mysqli_query( $con, $sql5 )or die( mysqli_error( $con ) );
							while ( $row5 = mysqli_fetch_array( $result5 ) ) {
								echo '<option value="' . $row5[ 'Sem_Id' ] . '">' . $row5[ 'Sem_Name' ] . '</option>';
							}
							?>
						</select>
					</div>
					<div class="form-actions no-margin-bottom" style="text-align:center;">
						<button type="button" name="addstudent" id="students" class="btn btn-info btn-lg ">
							<i class="fa fa-upload"></i> Add Student
						</button>
					
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
          <!-- /.modal -->