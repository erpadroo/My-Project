<?php
	session_start();
	include 'Php_Include/dbcon.php';
	if(isset($_POST['hod_login'])) {
		$email = $_POST['email'];
		$pass = $_POST['password'];
		$sql2= "select * from faculty,departments where faculty.Fac_id=Departments.dept_hod and fac_email = '$email' and hod_password = '$pass'";
		$result2 = mysqli_query($con,$sql2) or die(mysqli_error($con));
		$numrows2 = mysqli_num_rows($result2);
		if($numrows2 == 1){
			$_SESSION['email'] = $email;
			header('Location:Main_Site/Head_Of_Departments.php');
		}
		$error = true;
	}	
	if(isset($_POST['faculty_login'])) {
		$email = $_POST['email'];
		$pass = $_POST['password'];
		$sql = "select * from faculty where Fac_email = '$email' and fac_password = '$pass'";
		$result = mysqli_query($con,$sql) or die(mysqli_error($con));
		$numrows = mysqli_num_rows($result);
		if($numrows == 1){
			$_SESSION['email'] = $email;
			header('Location:Main_Site/Staff_Members.php');
		}
		$error = true;
	}	
	if(isset($_POST['student_login'])) {
		$rollno = $_POST['s_email'];
		$s_password = $_POST['s_password'];
		$sql = "select * from students where rollno = '$rollno' and password = '$s_password'";
		$result = mysqli_query($con,$sql) or die(mysqli_error($con));
		$numrows = mysqli_num_rows($result);
		if($numrows == 1){
			$_SESSION['s_email'] = $rollno;
			header('Location:Main_Site/Students.php');
		}
		$error2 = true;
	}
?>