<?php
$host = "localhost";
$username = "root";
$password = "";
$con = mysqli_connect( 'localhost', 'root', '' )or die( mysqli_error() );
if ( !$con ) {
	die( "Cannot Connect to database" );
}
mysqli_select_db( $con, "SPS" )or die( mysqli_error( $con ) );
?>