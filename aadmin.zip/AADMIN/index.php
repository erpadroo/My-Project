<?php
	include "Php_Include/Upin.php";
	include "Php_Include/dbcon.php";	
	include "Php_Include/For_Students/Student_Password.php";
	?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Login Form</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
	<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
	<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
	<link rel="stylesheet" href="Css/style.css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- bootstrap datepicker -->
	<link rel="stylesheet" href="Main_Site/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
</head>
<body style="background: #6495ED;">
	<div class="pen-title">
		<!--<h1 style="color:#ffffff">Login Form</h1>
		<span>Pen <i class='fa fa-paint-brush'></i> + <i class='fa fa-code'></i> by <a href='http://andytran.me'>Andy Tran</a></span>-->
	</div>
	<!-- Form Module-->
	<div class="col-sm-6">
		<div class="module form-module">
			<div class="toggle"><i class="fa fa-user fa-user"></i>
				<div class="tooltip2">HOD Click Me</div>
			</div>
			<div class="form">
				<h2>Welcome Faculty Login To Your Account</h2>
				<?php if(isset($error)) echo '<p class="alert alert-danger" style="text-align:center;font-weight:bolder;">Invalid Login Details</p>'; ?>
				<form action="" method="post" id="forget">
					<div>
						<input type="text" name="email" placeholder="Email Id" required/>
					</div>
					<div>
						<input type="password" name="password" placeholder="Password" required autocomplete="off">
					</div>
					<button name="faculty_login">LogIn</button>
					<a data-toggle="modal" data-target="#faculty_forget" style="text-decoration:none">Forget Password?</a>
				</form>
			</div>
			<div class="form">
				<h2>Welcome HOD's LogIn To Your Account</h2>
				<form action="" method="post" id="forget">
					<div>
						<input type="text" name="email" placeholder="Email Id" required/>
					</div>
					<div>
						<input type="password" name="password" placeholder="Password" required autocomplete="off">
					</div>
					<button name="hod_login">LogIn</button>
				</form>
			</div>
		</div>
	</div>
	<!-- Form Module-->
	<div class="col-sm-6">
		<div class="module form-module">
			<div class="toggle2"><i class="fa fa-user fa-user"></i>
				<div class="tooltip2">Student Click Me</div>
			</div>
			<div class="form2">
				<h2>Welcome Students Register Here</h2>
				<?php 
							if(isset($error2)) echo '<p class="alert alert-danger" style="text-align:center;">Invalid Login Details...!</p>'; 
							if(isset($successs)) echo '<p class="alert alert-success" style="text-align:center;font-weight:bolder">Registered Successfully...!</p>';
							if(isset($errors)) echo '<p class="alert alert-danger" style="text-align:center;">Something Went Woring While Registring You...!</p>'; 
						?>
				<form name="search" role="form" method="POST" onkeypress="return event.keyCode != 13;">
					<div>
						<input name="search_text" id="search_text" type="text" class="form-control" placeholder="Search....................." autocomplete="off" required/>
					</div>
					<div>
						<div id="result"></div>
						<button name="set_password">Register</button>
					</div>
				</form>
			</div>
			<div class="form2">
				<h2>Welcome Students LogIn To Your Account</h2>
				<form method="post" id="forget">
					<div>
						<input type="text" name="s_email" placeholder="Email Id" required/>
					</div>
					<div>
						<input type="password" name="s_password" placeholder="Password" required autocomplete="off">
					</div>
					<button name="student_login">LogIn</button>
					<a data-toggle="modal" data-target="#student_forget" style="text-decoration:none">Forget Password?</a>
				</form>
			</div>
		</div>		
		<div id="student_forget" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Forget Password</h4>
					</div>
					<div class="modal-body">
					<div id="forgot"></div>
						<form id="image_form" method="post" enctype="multipart/form-data">
						<div class="form-group input-group">
							<span class="input-group-addon"> Roll Number </span>
							<input type="text" name="rollno" id="rollno" class="form-control" style="height:35px;" required />
						</div>
						<div class="form-group input-group">
							<span class="input-group-addon">Date Of Birth </span>
							<input type="text" name="dob" id="dob" class="form-control" style="height:35px;" required />
						</div>
							<div class="form-actions no-margin-bottom" style="text-align:center;">
								<button type="button" id="forget_pass_student" name="forget_pass_student" class="btn btn-success btn-lg ">
									Generate Password
								</button>
							
							</div>	
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
	    </div>
		<div id="faculty_forget" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Forget Password</h4>
					</div>
					<div class="modal-body">
					<div id="forgotf"></div>
						<form id="image_form" method="post" enctype="multipart/form-data">
						<div class="form-group input-group">
							<span class="input-group-addon"> Email Id </span>
							<input type="email" name="eid" id="eid" class="form-control" style="height:35px;" required />
						</div>
						<div class="form-group input-group">
							<span class="input-group-addon">Contact Number </span>
							<input type="text" name="econ" id="econ" class="form-control" style="height:35px;" required />
						</div>
							<div class="form-actions no-margin-bottom" style="text-align:center;">
								<button type="button" id="forget_pass_faculty" name="forget_pass_faculty" class="btn btn-success btn-lg ">
									Send Password
								</button>
							
							</div>	
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
	    </div>
	<script>
		$( document ).ready( function () {
		$("#forget_pass_student").click(function () {
		var rollno = $("#rollno").val();
		var dob = $("#dob").val();
		if(rollno==""){
			$("#rollno").focus();
		}
		else if(dob==""){
		$("#dob").focus();
		}
		else{
			$.ajax({
				type: "post",
				url: "Php_Include/For_Students/Forget_Password.php",
				data: {
					rollno: rollno,
					dob: dob
				},
				success: function (data) {
					$("#forgot").html(data);
					document.getElementById("rollno").value = '';
					document.getElementById("dob").value = '';
				}
			});			
		}
	});
	$("#forget_pass_faculty").click(function () {
		var eid = $("#eid").val();
		var econ = $("#econ").val();
		var phonef = econ.replace(/[^0-9]/g, '');
		var atpos = eid.indexOf("@");
		var dotpos = eid.lastIndexOf(".");
		 if (eid=="" || atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= eid.length) {
			alert("Not A Valid E-mail Address");
			$('#eid').val('');
			$('#eid').focus();
		}
		else if (econ=="" || phonef.length != 10) {
			alert('Phone Number Must Be 10 Digits.');
			$('#econ').val('');
			$('#econ').focus();
		}
		else{
			$.ajax({
				type: "post",
				url: "Php_Include/For_Staff/Forget_Password.php",
				data: {
					eid: eid,
					econ: econ
				},
				success: function (data) {
					$("#forgotf").html(data);
					document.getElementById("eid").value = '';
					document.getElementById("econ").value = '';
				}
			});			
		}
	});
	});
	
	</script>
</div>
	<script src="Js/index.js" type="text/javascript"></script>
	<!-- bootstrap datepicker -->
    <script src="Main_Site/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
	<script type="text/javascript">
	$( '#dob' ).datepicker( {
				autoclose: true
			} );
		$( document ).ready( function () {
			load_data();

			function load_data( query ) {
				$.ajax( {
					url: "Php_Include/For_Students/Student_Registeration.php",
					method: "POST",
					data: {
						query: query
					},
					success: function ( data ) {
						$( '#result' ).html( data );
					}
				} );
			}
			$( '#search_text' ).keyup( function () {
				var search = $( this ).val();
				if ( search != '' ) {
					load_data( search );
				} else {
					load_data();
				}
			} );		
		} );
	</script>
</body>

</html>